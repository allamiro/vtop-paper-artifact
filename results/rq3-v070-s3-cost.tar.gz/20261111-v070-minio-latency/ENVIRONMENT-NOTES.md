# Environment notes: emulated-latency S3 cost campaign (C25)

Per chunk: quiet gate, load averages, top CPU processes, foreign Docker CPU
(busy = a foreign container or host process above 50% of one core, or another
exp_baseline.py / exp_minio_cost.py), and the runs exposed to busy samples.

## Chunk +20 ms RTT, reps 0..1 (attempt 1)

- busy 2026-11-11T21:47:59+0100: container vtop-670-dev 100%
- busy 2026-11-11T21:48:44+0100: container agitated_hawking 773%; container vtop-670-dev 756%
- busy 2026-11-11T21:49:07+0100: container vtop-670-dev 99%; host Google Chrome Helper (Aperitif Renderer) 58%
- busy 2026-11-11T21:49:29+0100: container vtop671-ci 127%; container vtop-670-dev 100%
- busy 2026-11-11T21:50:36+0100: container cool_goldberg 283%; container vtop-670-dev 1138%; host WindowServer 56%
- busy 2026-11-11T21:50:59+0100: container vtop671-ci 280%; container vtop-670-dev 200%
- busy 2026-11-11T21:51:21+0100: container confident_shtern 66%; container hungry_cori 96%; container vtop671-ci 72%; container vtop-670-dev 858%
- busy 2026-11-11T21:51:43+0100: container hungry_cori 77%; container vtop-670-dev 114%
- busy 2026-11-11T21:52:06+0100: container hungry_cori 287%
- busy 2026-11-11T21:52:28+0100: container hungry_cori 436%; container vtop671-ci 94%
- quiet gate passed after 360 s at 2026-11-11T21:53:37+0100
- uptime: `21:53  up 25 days,  6:55, 3 users, load averages: 14.57 17.15 13.13`
- top CPU: com.apple.Virtualization.VirtualMachine 908.7%; WindowServer 26.9%; com.apple.WebKit.WebContent 22.6%; com.apple.WebKit.WebContent 13.2%; com.apple.WebKit.Networking 13.1%; Code Helper (Renderer) 8.6%; Code Helper (Renderer) 6.1%; com.apple.WebKit.WebContent 5.8%
- foreign containers (top 5 CPU): wm-e2e-check 0.7%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_282 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.1%; k8s_orchestration-mcp_stillpoint-orchestration-mcp-6b65c6864b-xmlx7_stillpoint-helm_8e7f9716-ae3f-488d-89db-17d8c2884ca4_9 0.1%
- chunk ran 2026-11-11T21:53:37+0100 .. 2026-11-11T21:57:03+0100; driver exit 0; 39 monitor samples, 39 busy; post-chunk uptime: `21:57  up 25 days,  6:58, 3 users, load averages: 20.38 17.52 14.04`
- busy sample 2026-11-11T21:53:37+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:53:44+0100: vtop671-ci 201%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:53:49+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:53:54+0100: vtop671-ci 89%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:00+0100: vtop671-ci 195%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:05+0100: vtop671-ci 202%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:10+0100: vtop671-ci 87%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:15+0100: vtop671-ci 101%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:21+0100: vtop671-ci 100%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:26+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:31+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:36+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:42+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:47+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:52+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:54:57+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:03+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:08+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:13+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:18+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:24+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:29+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:34+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:39+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:44+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:50+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:55:55+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:00+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:05+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:11+0100: vtop671-ci 60%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:16+0100: vtop671-ci 642%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:21+0100: vtop671-ci 457%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:27+0100: exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:32+0100: vtop671-ci 745%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:37+0100: vtop671-ci 199%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:42+0100: vtop671-ci 201%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:48+0100: sad_jang 98%; vtop671-ci 1195%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:53+0100: vtop671-ci 1240%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- busy sample 2026-11-11T21:56:59+0100: vtop671-ci 94%; exp: 93514 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 20
- exposed runs moved to runs-exposed.jsonl and re-run: bgl/blake3/r0, bgl/blake3/r1, bgl/sha256/r0, bgl/sha256/r1, bgl/size-only/r0, bgl/size-only/r1, hdfs/blake3/r0, hdfs/blake3/r1, hdfs/sha256/r0, hdfs/sha256/r1, hdfs/size-only/r0, hdfs/size-only/r1, ssh/blake3/r0, ssh/blake3/r1, ssh/sha256/r0, ssh/sha256/r1, ssh/size-only/r0, ssh/size-only/r1

## Chunk +20 ms RTT, reps 0..1 (attempt 2)

- busy 2026-11-11T21:57:06+0100: container vtop671-ci 112%; host duetexpertd 68%
- 21:57:10 orchestrator stopped by hand during the attempt-2 gate. Attempt 1 flagged all 18 runs because the
  sampler counted the orchestrator's own driver process as "another experiment" (fixed in
  `code/run_minio_latency.py`: the orchestrator's child is excluded). Re-evaluated against foreign-container
  samples only, 9 of the 18 runs were exposed (vtop671-ci 87–201% at 21:53:44–21:54:21 and 60–1240% at
  21:56:11–21:56:59): ssh/blake3/r0, hdfs/size-only/r1, bgl/size-only/r0, hdfs/blake3/r0, bgl/size-only/r1,
  ssh/sha256/r0, bgl/blake3/r1, bgl/sha256/r0, hdfs/sha256/r0. All 18 remain in runs-exposed.jsonl and all
  18 are re-run (conservative); none of them is used in the analysis.

## Chunk +20 ms RTT, reps 0..1 (attempt 1)

- busy 2026-11-11T21:57:56+0100: container vtop671-msrv 612%; container sad_jang 73%
- busy 2026-11-11T21:58:18+0100: container naughty_babbage 54%; container vtop671-ci 280%
- busy 2026-11-11T21:58:41+0100: container naughty_babbage 212%; container vtop671-ci 1194%
- busy 2026-11-11T21:59:03+0100: container vtop671-ci 100%
- busy 2026-11-11T21:59:26+0100: container vtop671-ci 100%
- busy 2026-11-11T21:59:48+0100: container vtop671-ci 101%
- busy 2026-11-11T22:00:10+0100: container vtop671-ci 101%
- busy 2026-11-11T22:00:55+0100: container vtop671-ci 1515%; host Google Chrome Helper (Aperitif Renderer) 148%
- busy 2026-11-11T22:01:18+0100: container vtop671-ci 1343%; host Google Chrome Helper (Aperitif Renderer) 78%; host Kimi Helper 78%; host Code Helper (Renderer) 54%
- busy 2026-11-11T22:02:02+0100: container vtop671-ci 91%; host Google Chrome Helper (Aperitif Renderer) 112%; host WindowServer 54%
- busy 2026-11-11T22:02:24+0100: container vtop671-ci 199%
- 22:02:30 orchestrator stopped by hand during the gate (no runs in progress) to relax the host-process threshold to 200% (interactive Chrome/WindowServer spikes) and to add the bandwidth level; containers stay at 50%.

## Chunk +20 ms RTT, reps 0..1 (attempt 1)

- quiet gate passed after 47 s at 2026-11-11T22:06:48+0100
- uptime: `22:06  up 25 days,  7:08, 3 users, load averages: 7.41 12.84 13.87`
- top CPU: com.apple.Virtualization.VirtualMachine 55.0%; WindowServer 54.1%; Kimi Helper (Renderer) 34.6%; com.apple.WebKit.WebContent 22.3%; com.apple.WebKit.Networking 18.2%; Kimi Helper 13.2%; Google Chrome Helper (Aperitif) 9.7%; com.apple.WebKit.WebContent 8.4%
- foreign containers (top 5 CPU): wm-e2e-check 0.9%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.2%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.2%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_282 0.2%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-s79zx_stillpoint-helm_68b844a8-3159-422d-b854-7d09a128078e_10 0.1%
- chunk ran 2026-11-11T22:06:48+0100 .. 2026-11-11T22:06:50+0100; driver exit 1; 1 monitor samples, 1 busy; post-chunk uptime: `22:06  up 25 days,  7:08, 3 users, load averages: 6.82 12.63 13.78`
- driver failed; stopping (see console output)
- 22:06:50 driver failed before any run: the MinIO image `vtop-minio:RELEASE.2025-09-07T16-13-09Z`
  (id `sha256:fd501265…`, used by the clean 0 ms set and by the 21:46–22:05 smoke tests) and every other
  MinIO image had been removed from the host by a process outside this campaign between ~22:05 and 22:06.
  Rebuilt at 22:07:36–22:07:39 from `.tmp/vtop-engine-v0.7.0/docker/minio/Dockerfile` (MinIO commit
  07c3a429, base images pinned by digest). The build was fully served from the Docker build cache (image
  created 2026-11-10T01:19:34Z, the original build); `minio --version` reports
  RELEASE.2025-09-07T16-13-09Z (commit-id=07c3a429bfed433e49018cb0f78a52145d4bedeb). The new image id is
  `sha256:b44903abe6e6d9a6177ba2e23d18bd648746232fa0d365f688fa69b290ab12f9`. Every run in this directory
  uses the rebuilt image (recorded in run.json `minio_image_id`); this is one more reason the 0 ms
  comparison is descriptive only.
- run.json from attempt 1 (old image id, 18 discarded runs) renamed to run-superseded-attempt1.json; the driver writes a fresh run.json with the rebuilt image id.

## Chunk +20 ms RTT, reps 0..1 (attempt 1)

- quiet gate passed after 46 s at 2026-11-11T22:11:25+0100
- uptime: `22:11  up 25 days,  7:12, 3 users, load averages: 3.41 7.45 11.13`
- top CPU: Google Chrome Helper (Aperitif Renderer) 113.1%; WindowServer 23.3%; com.apple.Virtualization.VirtualMachine 22.6%; Google Chrome 16.7%; com.apple.WebKit.WebContent 16.0%; com.apple.WebKit.Networking 15.2%; com.apple.WebKit.WebContent 10.6%; Code Helper (Renderer) 9.4%
- foreign containers (top 5 CPU): wm-e2e-check 1.0%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-5bl6n_stillpoint-helm_ee38c016-1c99-4db5-b85a-9349dbdd8632_10 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_282 0.1%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.1%
- chunk ran 2026-11-11T22:11:25+0100 .. 2026-11-11T22:13:57+0100; driver exit 0; 30 monitor samples, 0 busy; post-chunk uptime: `22:13  up 25 days,  7:15, 3 users, load averages: 4.34 6.66 10.23`
- exposed runs: none

## Chunk +20 ms RTT, reps 2..3 (attempt 1)

- quiet gate passed after 46 s at 2026-11-11T22:14:45+0100
- uptime: `22:14  up 25 days,  7:16, 3 users, load averages: 3.50 6.11 9.84`
- top CPU: duetexpertd 84.9%; com.apple.Virtualization.VirtualMachine 80.2%; WindowServer 28.6%; com.apple.WebKit.WebContent 22.4%; com.apple.WebKit.Networking 16.0%; airportd 8.1%; TextInputMenuAgent 7.3%; com.apple.weather.menu 7.3%
- foreign containers (top 5 CPU): wm-e2e-check 1.3%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_282 0.1%; k8s_orchestration-mcp_stillpoint-orchestration-mcp-6b65c6864b-qv4cb_stillpoint-helm_d723462a-7b7f-4e16-a83e-8b404cb53a03_9 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.1%
- chunk ran 2026-11-11T22:14:45+0100 .. 2026-11-11T22:17:13+0100; driver exit 0; 29 monitor samples, 9 busy; post-chunk uptime: `22:17  up 25 days,  7:18, 3 users, load averages: 8.83 6.98 9.55`
- busy sample 2026-11-11T22:16:02+0100: heuristic_wright 70%
- busy sample 2026-11-11T22:16:07+0100: heuristic_wright 472%
- busy sample 2026-11-11T22:16:13+0100: heuristic_wright 773%
- busy sample 2026-11-11T22:16:18+0100: heuristic_wright 1566%
- busy sample 2026-11-11T22:16:23+0100: heuristic_wright 1282%
- busy sample 2026-11-11T22:16:28+0100: heuristic_wright 510%
- busy sample 2026-11-11T22:16:33+0100: heuristic_wright 84%
- busy sample 2026-11-11T22:16:54+0100: objective_lederberg 100%
- busy sample 2026-11-11T22:17:09+0100: objective_lederberg 85%
- exposed runs moved to runs-exposed.jsonl and re-run: bgl/blake3/r2, bgl/sha256/r2, bgl/size-only/r3, hdfs/blake3/r2, hdfs/blake3/r3, hdfs/size-only/r3, ssh/blake3/r2, ssh/blake3/r3, ssh/sha256/r2, ssh/size-only/r2, ssh/size-only/r3

## Chunk +20 ms RTT, reps 2..3 (attempt 2)

- busy 2026-11-11T22:17:16+0100: container eager_mendeleev 88%
- quiet gate passed after 70 s at 2026-11-11T22:18:25+0100
- uptime: `22:18  up 25 days,  7:19, 3 users, load averages: 5.58 6.50 9.18`
- top CPU: com.apple.Virtualization.VirtualMachine 94.3%; WindowServer 55.7%; Kimi Helper (Renderer) 40.7%; com.apple.WebKit.WebContent 19.3%; com.apple.WebKit.Networking 16.6%; Kimi Helper 14.9%; com.apple.WebKit.WebContent 12.0%; com.apple.WebKit.WebContent 10.4%
- foreign containers (top 5 CPU): wm-e2e-check 0.7%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.1%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_282 0.1%; k8s_orchestration-mcp_stillpoint-orchestration-mcp-6b65c6864b-xmlx7_stillpoint-helm_8e7f9716-ae3f-488d-89db-17d8c2884ca4_9 0.1%
- chunk ran 2026-11-11T22:18:25+0100 .. 2026-11-11T22:19:49+0100; driver exit 0; 17 monitor samples, 0 busy; post-chunk uptime: `22:19  up 25 days,  7:21, 3 users, load averages: 5.95 6.41 8.89`
- exposed runs: none

## Chunk +20 ms RTT, reps 4..5 (attempt 1)

- quiet gate passed after 46 s at 2026-11-11T22:20:38+0100
- uptime: `22:20  up 25 days,  7:22, 3 users, load averages: 5.91 6.35 8.74`
- top CPU: WindowServer 54.2%; Kimi Helper (Renderer) 44.6%; com.apple.Virtualization.VirtualMachine 41.6%; com.apple.WebKit.WebContent 36.0%; com.apple.WebKit.Networking 23.1%; Kimi Helper 20.0%; com.apple.WebKit.WebContent 11.3%; coreaudiod 4.7%
- foreign containers (top 5 CPU): wm-e2e-check 1.1%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-s79zx_stillpoint-helm_68b844a8-3159-422d-b854-7d09a128078e_10 0.3%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-5bl6n_stillpoint-helm_ee38c016-1c99-4db5-b85a-9349dbdd8632_10 0.3%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.3%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_282 0.2%
- chunk ran 2026-11-11T22:20:38+0100 .. 2026-11-11T22:23:03+0100; driver exit 0; 29 monitor samples, 0 busy; post-chunk uptime: `22:23  up 25 days,  7:24, 3 users, load averages: 6.00 5.79 8.09`
- exposed runs: none

## Chunk +20 ms RTT, reps 6..7 (attempt 1)

- quiet gate passed after 46 s at 2026-11-11T22:23:52+0100
- uptime: `22:23  up 25 days,  7:25, 3 users, load averages: 5.92 5.80 7.97`
- top CPU: Kimi Helper (Renderer) 59.9%; com.apple.Virtualization.VirtualMachine 58.6%; WindowServer 54.3%; Kimi Helper 16.4%; com.apple.WebKit.WebContent 12.9%; com.apple.WebKit.Networking 11.1%; com.apple.WebKit.WebContent 10.9%; com.apple.WebKit.GPU 6.5%
- foreign containers (top 5 CPU): k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-5bl6n_stillpoint-helm_ee38c016-1c99-4db5-b85a-9349dbdd8632_10 1.1%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-s79zx_stillpoint-helm_68b844a8-3159-422d-b854-7d09a128078e_10 0.8%; wm-e2e-check 0.8%; k8s_postgres_stillpoint-postgres-0_stillpoint-helm_212fc4ce-5de2-4cb7-8cf1-b3480355608c_9 0.6%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.3%
- chunk ran 2026-11-11T22:23:52+0100 .. 2026-11-11T22:26:18+0100; driver exit 0; 29 monitor samples, 0 busy; post-chunk uptime: `22:26  up 25 days,  7:27, 3 users, load averages: 5.52 5.87 7.66`
- exposed runs: none

## Chunk +20 ms RTT, reps 8..9 (attempt 1)

- quiet gate passed after 46 s at 2026-11-11T22:27:07+0100
- uptime: `22:27  up 25 days,  7:28, 3 users, load averages: 5.42 5.80 7.55`
- top CPU: Google Chrome Helper (Aperitif Renderer) 116.1%; Kimi Helper (Renderer) 105.1%; com.apple.Virtualization.VirtualMachine 60.0%; WindowServer 49.7%; Kimi Helper 17.0%; com.apple.WebKit.WebContent 16.1%; com.apple.WebKit.Networking 14.5%; Google Chrome Helper (Aperitif) 10.5%
- foreign containers (top 5 CPU): k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-5bl6n_stillpoint-helm_ee38c016-1c99-4db5-b85a-9349dbdd8632_10 1.3%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-s79zx_stillpoint-helm_68b844a8-3159-422d-b854-7d09a128078e_10 1.0%; wm-e2e-check 0.9%; k8s_postgres_stillpoint-postgres-0_stillpoint-helm_212fc4ce-5de2-4cb7-8cf1-b3480355608c_9 0.8%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_282 0.2%
- chunk ran 2026-11-11T22:27:07+0100 .. 2026-11-11T22:29:32+0100; driver exit 0; 29 monitor samples, 0 busy; post-chunk uptime: `22:29  up 25 days,  7:31, 3 users, load averages: 5.23 5.64 7.20`
- exposed runs: none

## Chunk +50 ms RTT, reps 0..1 (attempt 1)

- busy 2026-11-11T22:29:57+0100: container eager_grothendieck 857%; container inspiring_blackwell 952%
- busy 2026-11-11T22:30:19+0100: container inspiring_blackwell 100%
- quiet gate passed after 113 s at 2026-11-11T22:31:27+0100
- uptime: `22:31  up 25 days,  7:32, 3 users, load averages: 6.52 6.44 7.36`
- top CPU: com.apple.Virtualization.VirtualMachine 163.8%; WindowServer 52.5%; Kimi Helper (Renderer) 38.7%; Kimi Helper 19.2%; com.apple.WebKit.WebContent 15.7%; com.apple.WebKit.Networking 13.7%; com.apple.WebKit.WebContent 6.4%; coreaudiod 3.9%
- foreign containers (top 5 CPU): wm-e2e-check 0.8%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.2%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.2%; k8s_orchestration-mcp_stillpoint-orchestration-mcp-6b65c6864b-qv4cb_stillpoint-helm_d723462a-7b7f-4e16-a83e-8b404cb53a03_9 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_282 0.1%
- chunk ran 2026-11-11T22:31:27+0100 .. 2026-11-11T22:34:42+0100; driver exit 1; 38 monitor samples, 17 busy; post-chunk uptime: `22:34  up 25 days,  7:36, 3 users, load averages: 8.14 7.21 7.47`
- driver failed; stopping (see console output)
- 22:34:42 the driver stopped itself before run 17/18 of this chunk: its pre-run `pgrep -fl exp_baseline.py`
  matched a concurrent `pgrep` started by this orchestrator's monitor thread (no exp_baseline.py was running;
  the match was `3303 pgrep -fl exp_baseline.py`). Fixed in `code/exp_minio_cost.py` (a pgrep process is not
  an experiment). Because the orchestrator stopped before its exposure step, exposure was evaluated by hand
  with the same rule against this attempt's monitor samples: foreign containers beautiful_nobel 568%
  (22:32:00), elastic_cerf 99–1298% (22:32:46–22:33:17), upbeat_austin/vtop671-ci 59–299% (22:33:43–22:33:58),
  keen_mendeleev/vtop671-ci 96–359% (22:34:04–22:34:29). 14 of the 16 completed runs were exposed and moved to
  runs-exposed.jsonl: hdfs/size-only/r0–r1, bgl/size-only/r0–r1, ssh/size-only/r0–r1, ssh/sha256/r0–r1,
  hdfs/sha256/r1, hdfs/blake3/r1, bgl/sha256/r1, bgl/blake3/r0–r1, ssh/blake3/r1; they are re-run.

## Chunk +50 ms RTT, reps 0..1 (attempt 1)

- quiet gate passed after 47 s at 2026-11-11T22:36:17+0100
- uptime: `22:36  up 25 days,  7:37, 3 users, load averages: 7.01 7.29 7.49`
- top CPU: WindowServer 50.2%; Kimi Helper (Renderer) 47.2%; com.apple.Virtualization.VirtualMachine 40.4%; com.apple.WebKit.WebContent 21.2%; com.apple.WebKit.Networking 16.2%; Kimi Helper 16.1%; Google Chrome Helper (Aperitif Renderer) 7.4%; com.apple.WebKit.WebContent 6.2%
- foreign containers (top 5 CPU): wm-e2e-check 0.8%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.2%; k8s_orchestration-mcp_stillpoint-orchestration-mcp-6b65c6864b-xmlx7_stillpoint-helm_8e7f9716-ae3f-488d-89db-17d8c2884ca4_9 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.1%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_282 0.1%
- chunk ran 2026-11-11T22:36:17+0100 .. 2026-11-11T22:39:35+0100; driver exit 0; 39 monitor samples, 14 busy; post-chunk uptime: `22:39  up 25 days,  7:41, 3 users, load averages: 5.44 7.03 7.39`
- busy sample 2026-11-11T22:36:22+0100: vtop671-ci 415%
- busy sample 2026-11-11T22:36:48+0100: vtop671-ci 343%
- busy sample 2026-11-11T22:36:53+0100: vtop671-ci 1212%
- busy sample 2026-11-11T22:36:58+0100: vtop671-ci 892%
- busy sample 2026-11-11T22:37:08+0100: vtop671-ci 255%
- busy sample 2026-11-11T22:37:13+0100: vtop671-ci 1388%; exp: 3873 /opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Resources/Python.app/Contents/MacOS/Python /Users/ghost-m5/Desktop/GIT-PROJECTS/VTOP-Paper/research/experiments/rq3-cost-ablation/code/exp_minio_cost.py --out research/experiments/rq3-cost-ablation/results/20261111-v070-minio-latency --datasets ssh,bgl,hdfs --variants size-only,sha256,blake3 --rep-offset 0 --reps 2 --proxy --latency-ms 50
- busy sample 2026-11-11T22:37:19+0100: vtop671-ci 1006%
- busy sample 2026-11-11T22:37:24+0100: vtop671-ci 109%
- busy sample 2026-11-11T22:37:29+0100: vtop671-ci 189%
- busy sample 2026-11-11T22:38:41+0100: vtop671-ci 889%
- busy sample 2026-11-11T22:39:02+0100: vtop671-ci 200%
- busy sample 2026-11-11T22:39:07+0100: vtop671-ci 97%
- busy sample 2026-11-11T22:39:12+0100: vtop671-ci 199%
- busy sample 2026-11-11T22:39:27+0100: vtop671-ci 100%
- exposed runs moved to runs-exposed.jsonl and re-run: bgl/blake3/r1, bgl/sha256/r0, bgl/size-only/r0, bgl/size-only/r1, hdfs/sha256/r0, hdfs/sha256/r1, hdfs/size-only/r0, hdfs/size-only/r1, ssh/sha256/r0, ssh/sha256/r1, ssh/size-only/r0

## Chunk +50 ms RTT, reps 0..1 (attempt 2)

- busy 2026-11-11T22:39:59+0100: container vtop671-ci 136%
- busy 2026-11-11T22:40:21+0100: container vtop671-ci 132%
- quiet gate passed after 113 s at 2026-11-11T22:41:29+0100
- uptime: `22:41  up 25 days,  7:42, 3 users, load averages: 5.56 6.74 7.24`
- top CPU: WindowServer 49.0%; com.apple.Virtualization.VirtualMachine 37.7%; Kimi Helper (Renderer) 36.2%; com.apple.WebKit.WebContent 24.3%; com.apple.WebKit.Networking 19.7%; Google Chrome Helper (Aperitif Renderer) 16.2%; Code Helper (Renderer) 9.0%; Kimi Helper 8.5%
- foreign containers (top 5 CPU): vtop671-ci 4.3%; wm-e2e-check 0.8%; k8s_orchestration-mcp_stillpoint-orchestration-mcp-6b65c6864b-xmlx7_stillpoint-helm_8e7f9716-ae3f-488d-89db-17d8c2884ca4_9 0.3%; k8s_orchestration-mcp_stillpoint-orchestration-mcp-6b65c6864b-qv4cb_stillpoint-helm_d723462a-7b7f-4e16-a83e-8b404cb53a03_9 0.3%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.2%
- chunk ran 2026-11-11T22:41:29+0100 .. 2026-11-11T22:43:45+0100; driver exit 0; 27 monitor samples, 14 busy; post-chunk uptime: `22:43  up 25 days,  7:45, 3 users, load averages: 5.90 6.16 6.92`
- busy sample 2026-11-11T22:41:36+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:41:41+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:41:46+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:41:51+0100: vtop671-ci 101%
- busy sample 2026-11-11T22:41:56+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:42:01+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:42:06+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:42:11+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:42:16+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:42:22+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:42:27+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:42:32+0100: vtop671-ci 100%
- busy sample 2026-11-11T22:42:37+0100: vtop671-ci 101%
- busy sample 2026-11-11T22:42:42+0100: vtop671-ci 100%
- exposed runs moved to runs-exposed.jsonl and re-run: bgl/size-only/r0, bgl/size-only/r1, hdfs/sha256/r1, hdfs/size-only/r0, hdfs/size-only/r1, ssh/sha256/r1, ssh/size-only/r0

## Chunk +50 ms RTT, reps 0..1 (attempt 3)

- quiet gate passed after 46 s at 2026-11-11T22:44:33+0100
- uptime: `22:44  up 25 days,  7:46, 3 users, load averages: 4.34 5.70 6.71`
- top CPU: WindowServer 58.8%; Kimi Helper (Renderer) 54.7%; com.apple.Virtualization.VirtualMachine 53.5%; com.apple.WebKit.WebContent 31.6%; com.apple.WebKit.Networking 20.5%; com.apple.WebKit.WebContent 9.7%; WhatsApp 8.1%; Code Helper (Renderer) 7.8%
- foreign containers (top 5 CPU): wm-e2e-check 0.8%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.3%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.2%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_283 0.1%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-s79zx_stillpoint-helm_68b844a8-3159-422d-b854-7d09a128078e_10 0.1%
- chunk ran 2026-11-11T22:44:33+0100 .. 2026-11-11T22:46:04+0100; driver exit 0; 18 monitor samples, 0 busy; post-chunk uptime: `22:46  up 25 days,  7:47, 3 users, load averages: 7.30 6.14 6.75`
- exposed runs: none

## Chunk +50 ms RTT, reps 2..3 (attempt 1)

- quiet gate passed after 46 s at 2026-11-11T22:46:52+0100
- uptime: `22:46  up 25 days,  7:48, 3 users, load averages: 6.17 5.96 6.65`
- top CPU: com.apple.Virtualization.VirtualMachine 61.4%; WindowServer 50.9%; Kimi Helper (Renderer) 49.9%; com.apple.WebKit.WebContent 30.9%; com.apple.WebKit.Networking 24.4%; Google Chrome Helper (Aperitif Renderer) 8.5%; com.apple.WebKit.WebContent 7.6%; Code Helper (Renderer) 6.7%
- foreign containers (top 5 CPU): wm-e2e-check 0.8%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-f8wrp_stillpoint-helm_c2c1e95d-1e72-4c6f-b519-63e5f76d1198_271 0.3%; k8s_nats_stillpoint-nats-0_stillpoint-helm_4909268e-469c-4613-8aa6-5c687acd2745_9 0.2%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_283 0.2%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-5bl6n_stillpoint-helm_ee38c016-1c99-4db5-b85a-9349dbdd8632_10 0.1%
- chunk ran 2026-11-11T22:46:52+0100 .. 2026-11-11T22:50:26+0100; driver exit 0; 42 monitor samples, 0 busy; post-chunk uptime: `22:50  up 25 days,  7:51, 3 users, load averages: 5.58 6.14 6.59`
- exposed runs: none

## Chunk +50 ms RTT, reps 4..4 (attempt 1)

- quiet gate passed after 47 s at 2026-11-11T22:51:14+0100
- uptime: `22:51  up 25 days,  7:52, 3 users, load averages: 7.51 6.58 6.73`
- top CPU: Kimi Helper (Renderer) 141.7%; com.apple.Virtualization.VirtualMachine 76.3%; Google Chrome Helper (Aperitif Renderer) 71.7%; WindowServer 61.4%; Google Chrome 27.5%; com.apple.WebKit.WebContent 25.2%; Google Chrome Helper (Aperitif) 23.0%; com.apple.WebKit.Networking 16.7%
- foreign containers (top 5 CPU): wm-e2e-check 1.1%; k8s_postgres_stillpoint-postgres-0_stillpoint-helm_212fc4ce-5de2-4cb7-8cf1-b3480355608c_9 0.3%; k8s_ingestion-worker_stillpoint-ingestion-worker-58c45595b7-flq8n_stillpoint-helm_f0c29a85-bb79-4465-af97-5484043646fe_283 0.2%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-5bl6n_stillpoint-helm_ee38c016-1c99-4db5-b85a-9349dbdd8632_10 0.2%; k8s_ingestion-api_stillpoint-ingestion-api-76744c65b4-s79zx_stillpoint-helm_68b844a8-3159-422d-b854-7d09a128078e_10 0.2%
- chunk ran 2026-11-11T22:51:14+0100 .. 2026-11-11T22:53:04+0100; driver exit 0; 22 monitor samples, 0 busy; post-chunk uptime: `22:53  up 25 days,  7:54, 3 users, load averages: 7.13 6.64 6.73`
- exposed runs: none

## Chunk +50 ms RTT, 1250 KB/s each way, reps 0..0 (attempt 1)

- 22:53:05 orchestrator stopped by hand during the quiet gate of the first bandwidth-capped chunk, before any
  bandwidth-capped run started: the +50 ms, 10 Mbit/s (1250 KB/s each way) level was **cancelled by the author
  for time** (submission tonight), not because of a failure. The +20 ms (90 runs) and +50 ms (45 runs) levels
  were complete. The driver and orchestrator keep the `--bandwidth-kbps` option (tested only in scratch smoke
  runs, not used for any result here). Containers rq3-minio and rq3-toxiproxy were removed by the driver after
  each chunk; the Docker network rq3net (created by this campaign's first run) was removed at the end.
