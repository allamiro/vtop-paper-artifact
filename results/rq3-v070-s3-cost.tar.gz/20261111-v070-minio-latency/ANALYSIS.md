# Emulated-latency S3 verification-cost analysis (C25)

VTOP v0.7.0 (`6c8f386`), native S3 backend, MinIO behind Toxiproxy `ghcr.io/shopify/toxiproxy:2.12.0` on one local Docker network. The latency is emulated:
a latency toxic of half the stated round-trip time in each direction, jitter 0, no bandwidth limit.
This is not a real WAN or public-cloud S3. All engine S3 traffic (PUT, HEAD, GET) passes the proxy;
the harness's cleanup, listing and oracle reads use the direct endpoint.

Each latency level is analysed on its own against size-only at the same latency. Throughput is the
median steady-state MiB/s with a percentile-bootstrap 95% CI (B = 10,000). The change is
100 × (variant median − size-only median) / size-only median, with a bootstrap CI on the difference
of medians; negative values are slowdowns; *resolved* means the CI excludes zero.
Read-back MiB follows the clean set (stored object bytes for BLAKE3). Proxy MiB from store is
measured: Toxiproxy's downstream byte counter for the run (all responses, including GET bodies).

## +20 ms RTT (10 ms each way)

90 runs: 3 datasets × 3 variants × 10 repetitions. Every run drained. The first repetition of every cell passed the independent S3 digest-and-byte-exact oracle (9/9). Longest run: 15.5 s wall.

Delay check (median of 50 kept-alive HEAD requests, per chunk): direct 1.11 ms, proxy without toxics 0.89 ms, with toxics 24.57 ms (+23.68); direct 0.88 ms, proxy without toxics 0.76 ms, with toxics 23.03 ms (+22.27); direct 1.21 ms, proxy without toxics 0.99 ms, with toxics 24.43 ms (+23.44); direct 1.27 ms, proxy without toxics 1.01 ms, with toxics 24.11 ms (+23.09); direct 1.18 ms, proxy without toxics 1.06 ms, with toxics 24.25 ms (+23.19); direct 0.94 ms, proxy without toxics 1.17 ms, with toxics 24.35 ms (+23.18).

| Dataset | Variant | MiB/s [95% CI] | Change vs size-only [95% CI] | Resolved | Total ms/batch | CPU s/GiB | Read-back MiB | Proxy MiB from store |
|---|---|---:|---:|---|---:|---:|---:|---:|
| SSH | size-only | 121.12 [117.50, 124.56] | 0.00% [0.00, 0.00] | — | 139.17 | 4.852 | 0.000 | 0.007 |
| SSH | sha256 | 119.76 [115.62, 122.71] | -1.12% [-5.80, 2.43] | no | 140.00 | 4.860 | 0.000 | 0.008 |
| SSH | blake3 | 97.88 [96.34, 99.99] | -19.18% [-21.97, -16.47] | yes | 194.17 | 5.194 | 4.914 | 4.932 |
| BGL | size-only | 148.22 [147.28, 150.57] | 0.00% [0.00, 0.00] | — | 154.91 | 3.365 | 0.000 | 0.053 |
| BGL | sha256 | 147.75 [146.59, 149.39] | -0.32% [-2.24, 1.03] | no | 156.20 | 3.354 | 0.000 | 0.060 |
| BGL | blake3 | 114.44 [113.57, 115.48] | -22.79% [-24.16, -21.85] | yes | 217.33 | 3.812 | 67.203 | 67.347 |
| HDFS | size-only | 149.85 [148.58, 152.78] | 0.00% [0.00, 0.00] | — | 155.99 | 3.263 | 0.000 | 0.110 |
| HDFS | sha256 | 149.46 [149.02, 152.00] | -0.26% [-2.29, 1.59] | no | 156.88 | 3.256 | 0.000 | 0.125 |
| HDFS | blake3 | 115.18 [114.35, 115.80] | -23.14% [-24.89, -22.19] | yes | 219.47 | 3.732 | 145.919 | 146.220 |

BLAKE3 read-back vs store SHA-256 at the same condition:

- SSH: -18.26% [-20.56, -14.67] (resolved)
- BGL: -22.54% [-23.58, -21.45] (resolved)
- HDFS: -22.94% [-24.22, -22.42] (resolved)

## +50 ms RTT (25 ms each way)

45 runs: 3 datasets × 3 variants × 5 repetitions. Every run drained. The first repetition of every cell passed the independent S3 digest-and-byte-exact oracle (9/9). Longest run: 25.2 s wall.

Delay check (median of 50 kept-alive HEAD requests, per chunk): direct 1.05 ms, proxy without toxics 0.95 ms, with toxics 55.03 ms (+54.09); direct 1.33 ms, proxy without toxics 1.07 ms, with toxics 54.44 ms (+53.38); direct 1.03 ms, proxy without toxics 0.89 ms, with toxics 55.19 ms (+54.30); direct 1.11 ms, proxy without toxics 1.09 ms, with toxics 55.17 ms (+54.07); direct 1.11 ms, proxy without toxics 0.98 ms, with toxics 55.42 ms (+54.44).

| Dataset | Variant | MiB/s [95% CI] | Change vs size-only [95% CI] | Resolved | Total ms/batch | CPU s/GiB | Read-back MiB | Proxy MiB from store |
|---|---|---:|---:|---|---:|---:|---:|---:|
| SSH | size-only | 81.72 [77.96, 82.70] | 0.00% [0.00, 0.00] | — | 264.67 | 5.086 | 0.000 | 0.007 |
| SSH | sha256 | 80.26 [79.69, 81.53] | -1.79% [-3.06, 2.94] | no | 267.67 | 5.085 | 0.000 | 0.008 |
| SSH | blake3 | 62.10 [59.79, 63.55] | -24.02% [-26.84, -20.35] | yes | 386.00 | 5.403 | 4.914 | 4.932 |
| BGL | size-only | 92.09 [91.39, 93.65] | 0.00% [0.00, 0.00] | — | 281.87 | 3.570 | 0.000 | 0.053 |
| BGL | sha256 | 91.68 [91.07, 93.39] | -0.45% [-2.26, 1.41] | no | 283.13 | 3.588 | 0.000 | 0.060 |
| BGL | blake3 | 67.27 [66.86, 67.83] | -26.95% [-28.23, -26.11] | yes | 409.17 | 4.137 | 67.203 | 67.347 |
| HDFS | size-only | 92.67 [92.14, 93.16] | 0.00% [0.00, 0.00] | — | 283.17 | 3.478 | 0.000 | 0.110 |
| HDFS | sha256 | 91.89 [91.76, 93.25] | -0.84% [-1.36, 0.63] | no | 284.33 | 3.551 | 0.000 | 0.125 |
| HDFS | blake3 | 67.38 [65.88, 67.94] | -27.29% [-28.91, -26.68] | yes | 412.25 | 3.975 | 145.919 | 146.220 |

BLAKE3 read-back vs store SHA-256 at the same condition:

- SSH: -22.63% [-25.50, -20.77] (resolved)
- BGL: -26.62% [-27.97, -25.72] (resolved)
- HDFS: -26.68% [-28.31, -26.06] (resolved)

## Across latency levels (descriptive only)

Median steady-state MiB/s. The 0 ms column is the K38 clean set (`20261111-v070-minio-cost-clean`): a different session, and without the proxy hop. No confidence interval or significance is claimed across levels.

| Dataset | Variant | 0 ms (clean set) | +20 ms | +50 ms |
|---|---|---:|---:|---:|
| SSH | size-only | 202.31 | 121.12 | 81.72 |
| SSH | sha256 | 194.60 | 119.76 | 80.26 |
| SSH | blake3 | 189.24 | 97.88 | 62.10 |
| BGL | size-only | 280.09 | 148.22 | 92.09 |
| BGL | sha256 | 287.68 | 147.75 | 91.68 |
| BGL | blake3 | 255.10 | 114.44 | 67.27 |
| HDFS | size-only | 274.02 | 149.85 | 92.67 |
| HDFS | sha256 | 289.39 | 149.46 | 91.89 |
| HDFS | blake3 | 262.01 | 115.18 | 67.38 |

## Interpretation constraints

- Emulated latency over a local Docker network on one host; not a real WAN, not public-cloud S3.
- No bandwidth limit: the toxic delays data but does not throttle it, so read-back download time is bounded by local Docker throughput, not by WAN bandwidth. A planned +50 ms, 10 Mbit/s (1250 KB/s each way) bandwidth-capped level was cancelled by the author for time before it started; no run of it exists.
- The engine's TCP handshake to Toxiproxy is local; the latency applies to data in each direction.
- Native-S3 detailed stage fields can be zero in v0.7.0; zero is not treated as a measured stage cost.
- HTTP request counts were not observed and are not inferred; proxy byte counters (per run, counted when connections close) are observed.
- MinIO image: rebuilt from the same Dockerfile and source commit after the original image was removed from the host by an outside process (image id differs from the 0 ms set; see ENVIRONMENT-NOTES.md).
- Runs exposed to foreign CPU load were moved to runs-exposed.jsonl and re-run (61 runs); see ENVIRONMENT-NOTES.md.
