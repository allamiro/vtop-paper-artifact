# Environment and overlap notes — original MinIO campaign

## Original records preserved, but excluded from manuscript claims

The original `runs.jsonl`, `run.json`, `summary.json`, and `ANALYSIS.md` in this directory are preserved for
provenance. They are **not** the clean evidence set for manuscript use.

Claude's review identified three windows in which another experiment could have overlapped this campaign
(all local +0100, 2026-11-11):

1. 19:30:47–19:31:36 — SSH rep 0 chunk (5 runs).
2. 19:39:00–19:39:35 — BGL reps 5–9 chunk (25 runs).
3. 19:47:10–19:47:58 — the end of HDFS reps 4–6 and the start of HDFS reps 7–9 (30 runs total).

The original records have no per-run timestamps, so every run in those chunks is conservatively treated as
exposed. The original analysis's resolved BLAKE3 penalties of 10.39% on BGL and 12.59% on HDFS are excluded.

## Replacement and clean assembly

All 60 exposed runs were repeated with no `exp_baseline.py` process at run start. The replacements have
per-run `started_at`, `finished_at`, and quiet-check fields and are stored in
`../20261111-v070-minio-cost-rerun/`.

The clean assembly in `../20261111-v070-minio-cost-clean/` contains 90 original unexposed runs and 60
replacements. It is the only dataset to use for revised analysis. In the clean analysis, service SHA-256
and BLAKE3 read-back both have no resolved throughput penalty against size-only on any dataset; the
uncompressed penalty remains resolved on all three datasets.
