# Networked MinIO verification-cost analysis

150 matrix runs: 3 datasets × 5 variants × 10 repetitions. VTOP v0.7.0, native S3,
host to Docker MinIO with no fault proxy and no injected faults. Every run drained.
The first repetition of every cell passed the independent S3 byte-exact oracle (15/15).

Throughput is the median steady-state MiB/s with a percentile-bootstrap 95% CI.
The drop is 100 × (variant median − size-only median) / size-only median,
with a bootstrap CI on the difference of medians; negative values are slowdowns. BLAKE3 read-back bytes are the
stored object bytes; service SHA-256 does not download the object body for verification.

| Dataset | Variant | MiB/s [95% CI] | Change vs size-only [95% CI] | Total ms/batch | CPU s/GiB | Read-back MiB |
|---|---|---:|---:|---:|---:|---:|
| SSH | size-only | 202.31 [171.74, 209.45] | 0.00% [0.00, 0.00] | 46.33 | 4.405 | 0.000 |
| SSH | sha256 | 194.60 [171.16, 198.45] | -3.81% [-15.69, 11.89] | 48.50 | 4.483 | 0.000 |
| SSH | blake3 | 186.26 [141.25, 197.43] | -7.93% [-31.14, 2.84] | 54.67 | 4.776 | 4.914 |
| SSH | sha256+mac | 187.58 [169.91, 205.22] | -7.28% [-18.08, 7.80] | 47.50 | 4.587 | 0.000 |
| SSH | sha256-nocomp | 75.14 [66.33, 81.37] | -62.86% [-67.54, -57.13] | 219.00 | 8.929 | 0.000 |
| BGL | size-only | 286.17 [273.60, 292.38] | 0.00% [0.00, 0.00] | 60.50 | 2.942 | 0.000 |
| BGL | sha256 | 285.49 [282.50, 288.96] | -0.24% [-2.51, 4.88] | 61.67 | 2.907 | 0.000 |
| BGL | blake3 | 256.43 [244.85, 257.87] | -10.39% [-15.11, -6.10] | 74.46 | 3.268 | 67.203 |
| BGL | sha256+mac | 282.30 [259.22, 285.87] | -1.35% [-9.42, 3.64] | 62.63 | 2.967 | 0.000 |
| BGL | sha256-nocomp | 91.42 [84.17, 95.99] | -68.05% [-70.57, -65.27] | 283.59 | 6.928 | 0.000 |
| HDFS | size-only | 295.53 [267.90, 298.83] | 0.00% [0.00, 0.00] | 61.80 | 2.793 | 0.000 |
| HDFS | sha256 | 287.32 [257.35, 293.64] | -2.78% [-13.06, 1.79] | 63.52 | 2.858 | 0.000 |
| HDFS | blake3 | 258.31 [229.59, 265.22] | -12.59% [-22.30, -7.43] | 77.36 | 3.186 | 145.919 |
| HDFS | sha256+mac | 286.58 [270.06, 289.81] | -3.03% [-8.20, 6.25] | 63.75 | 2.891 | 0.000 |
| HDFS | sha256-nocomp | 91.24 [88.94, 93.32] | -69.13% [-70.01, -66.35] | 289.33 | 6.879 | 0.000 |

## Interpretation constraints

- Native-S3 detailed stage fields can be zero in v0.7.0; zero is not treated as a measured stage cost.
- These are host-to-Docker MinIO measurements, not public-cloud S3 or a distributed deployment.
- HTTP request counts were not observed and are not inferred.
- Throughput changes are reported only with their confidence intervals; unresolved differences are not claimed as resolved effects.
