# Clean MinIO assembly

The original 150 matrix records remain unchanged. This dataset replaces all 60 runs whose chunks
overlapped the three C23 windows: SSH rep 0, BGL reps 5–9, and HDFS reps 4–9.

It contains 90 original unexposed records and 60 new quiet-host replacements. Every replacement
record has started_at/finished_at and a quiet-environment check. All 15 rep-0 oracle cells pass.
