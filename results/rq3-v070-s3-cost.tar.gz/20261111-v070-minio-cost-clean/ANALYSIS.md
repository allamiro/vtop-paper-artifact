# Networked MinIO verification-cost analysis

150 matrix runs: 3 datasets × 5 variants × 10 repetitions. VTOP v0.7.0, native S3,
host to Docker MinIO with no fault proxy and no injected faults. Every run drained.
Clean assembly: 90 original unexposed runs + 60 quiet-host replacement runs.
The original 150 records are preserved; all three overlap-window chunks were replaced.
Replacement records include per-run timestamps and quiet-environment checks.

The first repetition of every cell passed the independent S3 byte-exact oracle (15/15).

Throughput is the median steady-state MiB/s with a percentile-bootstrap 95% CI.
The drop is 100 × (variant median − size-only median) / size-only median,
with a bootstrap CI on the difference of medians; negative values are slowdowns. BLAKE3 read-back bytes are the
stored object bytes; service SHA-256 does not download the object body for verification.

| Dataset | Variant | MiB/s [95% CI] | Change vs size-only [95% CI] | Total ms/batch | CPU s/GiB | Read-back MiB |
|---|---|---:|---:|---:|---:|---:|
| SSH | size-only | 202.31 [193.33, 209.45] | 0.00% [0.00, 0.00] | 46.00 | 4.357 | 0.000 |
| SSH | sha256 | 194.60 [171.38, 198.45] | -3.81% [-16.16, 0.66] | 48.50 | 4.483 | 0.000 |
| SSH | blake3 | 189.24 [141.02, 197.80] | -6.46% [-31.14, 0.27] | 54.50 | 4.748 | 4.914 |
| SSH | sha256+mac | 189.56 [170.23, 205.22] | -6.30% [-17.01, 2.39] | 47.50 | 4.524 | 0.000 |
| SSH | sha256-nocomp | 75.14 [62.96, 81.37] | -62.86% [-69.25, -58.79] | 219.00 | 9.172 | 0.000 |
| BGL | size-only | 280.09 [244.36, 288.18] | 0.00% [0.00, 0.00] | 61.26 | 3.007 | 0.000 |
| BGL | sha256 | 287.68 [281.89, 289.61] | 2.71% [-1.22, 16.99] | 61.72 | 2.909 | 0.000 |
| BGL | blake3 | 255.10 [197.96, 256.89] | -8.92% [-30.72, 1.79] | 74.70 | 3.290 | 67.203 |
| BGL | sha256+mac | 282.38 [277.41, 286.31] | 0.82% [-3.56, 14.33] | 62.48 | 2.964 | 0.000 |
| BGL | sha256-nocomp | 95.75 [87.13, 98.07] | -65.81% [-69.37, -62.02] | 274.30 | 6.840 | 0.000 |
| HDFS | size-only | 274.02 [241.97, 298.46] | 0.00% [0.00, 0.00] | 62.73 | 3.061 | 0.000 |
| HDFS | sha256 | 289.39 [260.22, 295.13] | 5.61% [-7.94, 20.26] | 63.36 | 2.850 | 0.000 |
| HDFS | blake3 | 262.01 [246.20, 265.54] | -4.38% [-14.56, 8.63] | 75.20 | 3.185 | 145.919 |
| HDFS | sha256+mac | 280.40 [258.89, 288.39] | 2.33% [-9.65, 17.20] | 63.89 | 2.963 | 0.000 |
| HDFS | sha256-nocomp | 91.18 [87.32, 97.03] | -66.72% [-70.28, -61.16] | 289.62 | 6.887 | 0.000 |

## Interpretation constraints

- Native-S3 detailed stage fields can be zero in v0.7.0; zero is not treated as a measured stage cost.
- These are host-to-Docker MinIO measurements, not public-cloud S3 or a distributed deployment.
- HTTP request counts were not observed and are not inferred.
- Throughput changes are reported only with their confidence intervals; unresolved differences are not claimed as resolved effects.
