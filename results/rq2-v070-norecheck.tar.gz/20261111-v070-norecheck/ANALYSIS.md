# V-norecheck ablation analysis

## Method

The isolated v0.7.0 ablation changes only `storage_still_verified` to return `true`
without downloading or rechecking the stored manifest or object. The production
checkout and all previously reported v0.7.0 results are unchanged. The mutation
procedure and independent oracle are the same as E-RQ2-R: archive, restore the
last ledger row to VERIFIED, mutate while stopped, restart, and compare committed
progress with intact archived coverage.

The campaign contains 36 trials: 2 datasets × 9 mutations × 2 repetitions. The
ablation engine hash is recorded in `run.json`, and the build log is retained.
The first attempted run used the production binary because the override was
applied to `exp_tamper.VTOPCTL` rather than the shared `vtoplab.VTOPCTL`. It is
excluded and preserved separately as `.tmp/norecheck-misconfigured`. The results
in this directory use the patched ablation binary.

## Results

| Mutation | Trials | Accepted | Unsafe commits | Complete archives |
|---|---:|---:|---:|---:|
| M0 control | 4 | 4 | 0 | 4 |
| M1 flip one object byte | 4 | 4 | 4 | 0 |
| M2 truncate object | 4 | 4 | 4 | 0 |
| M3 delete object | 4 | 4 | 4 | 0 |
| M4 replace object | 4 | 4 | 4 | 0 |
| M5 edit manifest, stale self-hash | 4 | 4 | 0 | 4 |
| M6 edit manifest, recomputed self-hash | 4 | 4 | 0 | 4 |
| M7 forge object and manifest | 4 | 4 | 4 | 0 |
| M8 delete manifest | 4 | 4 | 4 | 0 |
| **Total** | **36** | **36** | **24** | **12** |

All 32 mutations (plus 4 unmutated controls) were accepted. The 24 unsafe outcomes are M1–M4, M7,
and M8: 6 mutation classes × 2 datasets × 2 repetitions. M5 and M6 changed only
manifest metadata, leaving object bytes and the oracle's coverage intact; they
were accepted without an unsafe source position but still demonstrate that the
ablated recovery accepted altered evidence.

## Interpretation

Restart revalidation is the causal barrier that refuses stale or corrupted
recorded evidence before recovery commits source progress. Without it, VTOP
accepts deletion, corruption, replacement, forgery, and manifest deletion.
This supports H2.2's counterfactual prediction rather than merely arguing it
from code. It does not imply that the production build accepts these mutations:
the production E-RQ2-R suite rejected all 64 strong-mode mutations.
