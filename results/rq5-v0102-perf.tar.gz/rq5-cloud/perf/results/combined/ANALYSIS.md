# E-RQ5-PERF: VTOP v0.10.2 vs Confluent S3 Sink 12.1.15, Vector 0.61.0, Fluent Bit 5.2.0

Medians with percentile-bootstrap 95% CIs (B = 10000); differences are of medians, in % of the reference (`vtop-sha256-store`). Unresolved differences (CI includes 0) are not claimed. Warm-up runs excluded.

## Leg us-east-1 (session 20261121T144252Z-use1): 105 measured runs, 105 passing

RTT sink → S3 (TCP handshake, median of 20): 0.63 ms; broker probe: [{'host': 'vtop-eval-XXXXXXXXXXXX.s3.us-east-1.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.207.139', '16.15.214.46', '16.15.228.70', '16.15.229.197', '16.182.109.122', '16.182.42.154', '16.182.70.146', '52.217.113.42'], 'ok': 20, 'min_ms': 0.41, 'median_ms': 0.96, 'p90_ms': 1.33, 'max_ms': 1.74}, {'host': 'vtop-eval-XXXXXXXXXXXX.s3.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.164.73', '16.15.215.45', '16.15.244.74', '16.15.252.49', '16.15.255.123', '16.182.101.66', '54.231.135.242', '54.231.162.90'], 'ok': 20, 'min_ms': 0.45, 'median_ms': 0.62, 'p90_ms': 0.83, 'max_ms': 0.83}]

### Throughput (backlog drain, steady 10–90%)

Done = archived intact AND source-committed (the latency's end point); committed and archived alone are also given.

| Config | Runs | Done MiB/s | vs ref % | Committed MiB/s | Archived MiB/s | CPU s/GiB | Cores | Peak anon MiB | Objects/GiB | Raw MiB/object | Req USD/GiB (est.) | EC2 USD/GiB | Transfer USD/GiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 5 | 19.38 [18.12, 21.57] | -1.1 [-7.6, 10.0] | 19.40 [18.11, 21.73] | 19.14 [18.12, 21.85] | 22.14 [21.41, 22.79] | 0.42 | 229 | 78.4 | 13.62 | 0.00085 | 0.00099 | 0.00000 |
| vtop-sha256-store | 5 | 19.61 [19.30, 20.51] | – | 19.58 [19.30, 20.41] | 19.61 [19.57, 20.70] | 22.01 [21.84, 23.32] | 0.43 | 234 | 78.4 | 13.61 | 0.00088 | 0.00097 | 0.00000 |
| vtop-blake3-readback | 5 | 18.89 [18.15, 20.33] | -3.6 [-8.9, 3.7] | 18.67 [18.18, 20.51] | 19.36 [18.11, 20.33] | 23.18 [22.81, 23.46] | 0.42 | 218 | 78.4 | 13.57 | 0.00094 | 0.00101 | 0.00000 |
| vtop-sha256-gzip6 | 5 | 14.86 [12.44, 15.87] | -24.2 [-36.6, -19.1] | 14.90 [12.53, 15.76] | 14.82 [12.29, 15.68] | 47.60 [46.51, 48.72] | 0.69 | 215 | 78.4 | 13.52 | 0.00088 | 0.00129 | 0.00000 |
| confluent | 5 | 37.48 [34.17, 40.53] | 91.2 [74.3, 106.7] | 37.71 [34.17, 39.87] | 37.73 [35.43, 40.33] | 54.20 [49.95, 58.79] | 1.98 | 1205 | 63.8 | 16.24 | 0.00096 | 0.00051 | 0.00000 |
| vector | 5 | 9.61 [9.48, 9.85] | -51.0 [-53.1, -49.7] | 9.61 [9.48, 9.89] | 9.67 [9.51, 9.83] | 202.10 [196.90, 204.10] | 1.89 | 562 | 63.8 | 16.26 | 0.00032 | 0.00199 | 0.00000 |
| fluentbit | 5 | 4.83 [4.83, 4.83] | -75.3 [-76.4, -75.0] | 4.84 [4.84, 4.84] | 4.83 [4.83, 4.83] | 26.50 [25.86, 26.69] | 0.12 | 124 | 61.1 | 17.09 | 0.00030 | 0.00395 | 0.00000 |

### Latency (live, fixed rate; produce → durably in S3 and offset committed)

| Config | Runs | p50 s | p90 s | p99 s | max s | object-visible p50 | commit p50 | missing |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 3 | 2.70 [2.64, 2.77] | 4.23 [4.18, 4.31] | 4.64 [4.61, 4.73] | 4.77 [4.75, 4.87] | 2.61 [2.60, 2.71] | 2.64 [2.57, 2.69] | 0 |
| vtop-sha256-store | 3 | 2.75 [2.72, 2.77] | 4.28 [4.23, 4.29] | 4.70 [4.67, 4.70] | 4.88 [4.81, 4.90] | 2.71 [2.66, 2.72] | 2.65 [2.64, 2.66] | 0 |
| vtop-blake3-readback | 3 | 2.76 [2.69, 2.77] | 4.29 [4.25, 4.30] | 4.68 [4.67, 4.72] | 4.89 [4.87, 4.90] | 2.69 [2.63, 2.69] | 2.72 [2.66, 2.73] | 0 |
| confluent | 3 | 2.49 [2.48, 2.53] | 4.09 [4.08, 4.13] | 4.45 [4.44, 4.49] | 4.50 [4.49, 4.54] | 2.23 [2.23, 2.28] | 2.49 [2.48, 2.53] | 0 |
| vector | 3 | 5.15 [5.15, 5.17] | 7.66 [7.65, 7.67] | 8.96 [8.95, 8.97] | 9.16 [9.16, 9.18] | 2.67 [2.66, 2.68] | 5.15 [5.15, 5.17] | 0 |
| fluentbit | 3 | 3.15 [3.05, 3.30] | 4.83 [4.66, 4.99] | 5.41 [5.27, 5.55] | 5.80 [5.42, 5.95] | 3.15 [3.05, 3.30] | 0.39 [0.29, 0.44] | 0 |

### Recovery after one SIGKILL (times from the kill)

| Config | Runs | ready s | first commit s | first object s | re-steady s (not reached) | duplicates | complete |
|---|---:|---:|---:|---:|---:|---|---:|
| vtop-sha256-store | 3 | 0.05 [0.05, 0.05] | 2.75 [1.49, 3.97] | 0.49 [0.24, 3.99] | 11.26 [10.72, 11.77] (0) | [0, 0, 0] | 3/3 |
| confluent | 3 | 44.73 [44.23, 45.26] | 49.87 [49.41, 50.28] | 0.49 [0.35, 0.83] | 57.87 [57.66, 58.54] (0) | [0, 0, 0] | 3/3 |
| vector | 3 | 0.29 [0.26, 0.43] | 10.52 [10.50, 15.75] | 9.76 [9.74, 11.73] | 25.53 [20.51, 25.75] (0) | [240000, 240000, 120000] | 3/3 |
| fluentbit | 3 | 0.24 [0.23, 0.25] | 45.29 [45.27, 45.32] | 1.01 [0.96, 1.23] | 53.81 [53.77, 53.82] (0) | [0, 0, 0] | 3/3 |

### Storage faults on S3 (cloud counterpart of RQ4; native overwrite/delete, no proxy)

Class = when the damage landed relative to the sink's first commit into the damaged object's records (`damage_before_commit` and `commit_before_object_visible` are the RQ4-comparable cases).

| Fault/config | Trials | Classes | Unsafe (all) | Unsafe (RQ4-comparable / n) | Lost committed records | Complete | VTOP vs its verification | VTOP scrub/audit rc |
|---|---:|---|---:|---:|---|---:|---|---|
| corrupt/vtop-blake3-readback | 5 | {'ambiguous_within_one_poll': 3, 'damage_after_commit': 2} | 5 | 0 / 0 | [38176, 39058, 39003, 39498, 39058] | 0 | {'after_verification': 5} | [1, 1, 1, 1, 1] / [0, 0, 0, 0, 0] |
| corrupt/confluent | 5 | {'damage_after_commit': 1, 'damage_before_commit': 3, 'ambiguous_within_one_poll': 1} | 5 | 3 / 3 | [40000, 40000, 40000, 40000, 40000] | 0 | – | – / – |
| corrupt/vector | 5 | {'damage_before_commit': 5} | 5 | 5 / 5 | [40000, 40000, 40000, 40000, 40000] | 0 | – | – / – |
| corrupt/fluentbit | 5 | {'commit_before_object_visible': 5} | 5 | 5 / 5 | [42378, 42991, 42486, 42486, 41202] | 0 | – | – / – |
| lost/vtop-blake3-readback | 5 | {'ambiguous_within_one_poll': 4, 'damage_after_commit': 1} | 5 | 0 / 0 | [39003, 39498, 39498, 38176, 38176] | 0 | {'after_verification': 4, 'before_verification': 1} | [1, 1, 1, 1, 1] / [1, 1, 1, 1, 1] |
| lost/confluent | 5 | {'damage_before_commit': 5} | 5 | 5 / 5 | [40000, 40000, 40000, 40000, 40000] | 0 | – | – / – |
| lost/vector | 5 | {'damage_before_commit': 5} | 5 | 5 / 5 | [40000, 40000, 40000, 40000, 40000] | 0 | – | – / – |
| lost/fluentbit | 5 | {'commit_before_object_visible': 5} | 5 | 5 / 5 | [41202, 42486, 41202, 42486, 42378] | 0 | – | – / – |

### Correctness (oracle, every run)

| Cell | Runs | Complete | Unsafe | Lost committed | Duplicate records | Bad objects |
|---|---:|---:|---:|---:|---:|---:|
| corrupt/confluent | 5 | 0 | 5 | 200000 | 0 | 5 |
| corrupt/fluentbit | 5 | 0 | 5 | 211543 | 0 | 5 |
| corrupt/vector | 5 | 0 | 5 | 200000 | 0 | 5 |
| corrupt/vtop-blake3-readback | 5 | 0 | 5 | 194793 | 0 | 5 |
| kill/confluent | 3 | 3 | 0 | 0 | 0 | 0 |
| kill/fluentbit | 3 | 3 | 0 | 0 | 0 | 0 |
| kill/vector | 3 | 3 | 0 | 0 | 600000 | 0 |
| kill/vtop-sha256-store | 3 | 3 | 0 | 0 | 0 | 0 |
| live/confluent | 3 | 3 | 0 | 0 | 0 | 0 |
| live/fluentbit | 3 | 3 | 0 | 0 | 0 | 0 |
| live/vector | 3 | 3 | 0 | 0 | 0 | 0 |
| live/vtop-blake3-readback | 3 | 3 | 0 | 0 | 0 | 0 |
| live/vtop-sha256-store | 3 | 3 | 0 | 0 | 0 | 0 |
| live/vtop-size-only | 3 | 3 | 0 | 0 | 0 | 0 |
| lost/confluent | 5 | 0 | 5 | 200000 | 0 | 0 |
| lost/fluentbit | 5 | 0 | 5 | 209754 | 0 | 0 |
| lost/vector | 5 | 0 | 5 | 200000 | 0 | 0 |
| lost/vtop-blake3-readback | 5 | 0 | 5 | 194351 | 0 | 0 |
| tput/confluent | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/fluentbit | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vector | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vtop-blake3-readback | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vtop-sha256-gzip6 | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vtop-sha256-store | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vtop-size-only | 5 | 5 | 0 | 0 | 0 | 0 |

## Leg ap-southeast-2 (session 20261121T150129Z-apse2): 38 measured runs, 38 passing

RTT sink → S3 (TCP handshake, median of 20): 196.2 ms; broker probe: [{'host': 'vtop-eval-XXXXXXXXXXXX.s3.us-east-1.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.159.0', '16.15.160.249', '16.15.167.249', '16.15.191.185', '16.15.254.12', '52.216.211.90', '54.231.161.218', '54.231.230.226'], 'ok': 20, 'min_ms': 194.31, 'median_ms': 195.85, 'p90_ms': 198.56, 'max_ms': 198.72}, {'host': 'vtop-eval-XXXXXXXXXXXX.s3.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.183.224', '16.15.228.48', '16.15.245.25', '52.216.25.176', '52.216.25.40', '52.216.56.170', '52.217.232.50', '54.231.198.146'], 'ok': 20, 'min_ms': 193.87, 'median_ms': 196.07, 'p90_ms': 198.2, 'max_ms': 198.33}]

### Throughput (backlog drain, steady 10–90%)

Done = archived intact AND source-committed (the latency's end point); committed and archived alone are also given.

| Config | Runs | Done MiB/s | vs ref % | Committed MiB/s | Archived MiB/s | CPU s/GiB | Cores | Peak anon MiB | Objects/GiB | Raw MiB/object | Req USD/GiB (est.) | EC2 USD/GiB | Transfer USD/GiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 3 | 6.98 [6.73, 7.50] | 15.3 [9.3, 24.3] | 6.98 [6.73, 7.50] | 6.97 [6.78, 7.43] | 21.77 [20.70, 21.89] | 0.15 | 230 | 75.6 | 13.81 | 0.00082 | 0.00346 | 0.01375 |
| vtop-sha256-store | 3 | 6.05 [6.03, 6.16] | – | 6.05 [6.03, 6.16] | 6.08 [6.05, 6.17] | 21.52 [20.98, 22.74] | 0.13 | 223 | 78.4 | 13.53 | 0.00088 | 0.00398 | 0.01367 |
| vtop-blake3-readback | 3 | 5.00 [4.99, 5.09] | -17.4 [-18.9, -15.7] | 5.00 [4.99, 5.09] | 4.96 [4.93, 5.10] | 22.18 [21.99, 22.66] | 0.11 | 224 | 78.4 | 13.67 | 0.00094 | 0.00483 | 0.01677 |
| confluent | 3 | 24.89 [23.37, 24.97] | 311.1 [279.5, 313.9] | 24.56 [23.36, 24.97] | 24.86 [23.37, 25.18] | 57.82 [53.40, 62.30] | 1.41 | 953 | 63.8 | 16.24 | 0.00096 | 0.00097 | 0.01415 |
| vector | 3 | 9.24 [9.23, 9.48] | 52.6 [49.8, 57.2] | 9.37 [9.23, 9.55] | 9.35 [9.28, 9.48] | 207.77 [202.65, 209.63] | 1.88 | 567 | 63.8 | 16.25 | 0.00032 | 0.00261 | 0.01404 |
| fluentbit | 3 | 4.83 [4.83, 4.84] | -20.2 [-21.6, -19.7] | 4.83 [4.83, 4.84] | 4.83 [4.83, 4.84] | 26.23 [26.07, 26.40] | 0.12 | 141 | 61.1 | 17.10 | 0.00030 | 0.00499 | 0.01258 |

### Latency (live, fixed rate; produce → durably in S3 and offset committed)

| Config | Runs | p50 s | p90 s | p99 s | max s | object-visible p50 | commit p50 | missing |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 2 | 4.39 [4.33, 4.44] | 5.84 [5.81, 5.88] | 6.37 [6.35, 6.39] | 6.52 [6.48, 6.56] | 3.88 [3.81, 3.95] | 4.39 [4.33, 4.44] | 0 |
| vtop-sha256-store | 2 | 4.72 [4.67, 4.76] | 6.21 [6.14, 6.27] | 6.74 [6.72, 6.75] | 6.97 [6.90, 7.04] | 4.22 [4.13, 4.30] | 4.72 [4.67, 4.76] | 0 |
| vtop-blake3-readback | 2 | 6.85 [6.69, 7.02] | 8.27 [7.77, 8.76] | 9.25 [8.28, 10.23] | 9.60 [8.56, 10.63] | 5.86 [5.66, 6.07] | 6.85 [6.69, 7.02] | 0 |
| confluent | 2 | 4.17 [4.16, 4.19] | 5.80 [5.79, 5.81] | 6.21 [6.21, 6.22] | 6.39 [6.33, 6.45] | 4.14 [4.12, 4.15] | 4.03 [3.97, 4.09] | 0 |
| vector | 2 | 6.14 [6.11, 6.18] | 8.65 [8.61, 8.68] | 9.94 [9.91, 9.97] | 10.15 [10.11, 10.18] | 3.91 [3.89, 3.93] | 6.14 [6.11, 6.18] | 0 |
| fluentbit | 2 | 4.46 [4.44, 4.48] | 6.18 [6.16, 6.20] | 7.02 [6.91, 7.12] | 7.40 [7.29, 7.52] | 4.46 [4.44, 4.48] | 0.39 [0.30, 0.48] | 0 |

### Recovery after one SIGKILL (times from the kill)

| Config | Runs | ready s | first commit s | first object s | re-steady s (not reached) | duplicates | complete |
|---|---:|---:|---:|---:|---:|---|---:|
| vtop-sha256-store | 2 | 0.05 [0.05, 0.05] | 3.87 [1.24, 6.50] | 7.04 [6.52, 7.57] | 13.75 [11.50, 16.00] (0) | [0, 0] | 2/2 |
| confluent | 2 | 46.29 [43.18, 49.39] | 53.37 [50.89, 55.85] | 53.94 [51.37, 56.50] | 64.77 [57.41, 72.14] (0) | [0, 0] | 2/2 |
| vector | 2 | 0.33 [0.30, 0.36] | 15.61 [15.49, 15.73] | 7.30 [0.51, 14.09] | 25.62 [25.50, 25.74] (0) | [240000, 240000] | 2/2 |
| fluentbit | 2 | 0.27 [0.25, 0.29] | 45.30 [45.30, 45.31] | 3.54 [3.14, 3.95] | 53.81 [53.81, 53.81] (0) | [0, 0] | 2/2 |

### Correctness (oracle, every run)

| Cell | Runs | Complete | Unsafe | Lost committed | Duplicate records | Bad objects |
|---|---:|---:|---:|---:|---:|---:|
| kill/confluent | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/fluentbit | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/vector | 2 | 2 | 0 | 0 | 480000 | 0 |
| kill/vtop-sha256-store | 2 | 2 | 0 | 0 | 0 | 0 |
| live/confluent | 2 | 2 | 0 | 0 | 0 | 0 |
| live/fluentbit | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vector | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-blake3-readback | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-sha256-store | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-size-only | 2 | 2 | 0 | 0 | 0 | 0 |
| tput/confluent | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/fluentbit | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vector | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-blake3-readback | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-sha256-store | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-size-only | 3 | 3 | 0 | 0 | 0 | 0 |

## Distance effect (far leg vs us-east-1)

| Config | Done MiB/s change % | Live p50 change s |
|---|---:|---:|
| vtop-size-only | -64.0 [-67.6, -61.3] | 1.69 [1.56, 1.79] |
| vtop-sha256-store | -69.1 [-70.5, -68.6] | 1.97 [1.91, 2.04] |
| vtop-blake3-readback | -73.5 [-75.4, -72.3] | 4.09 [3.92, 4.32] |
| confluent | -33.6 [-40.9, -27.2] | 1.69 [1.63, 1.71] |
| vector | -3.9 [-6.2, -1.3] | 0.99 [0.94, 1.03] |
| fluentbit | -0.1 [-0.2, 0.2] | 1.31 [1.14, 1.43] |

## Interpretation constraints

- One instance pair per leg, one time window, t4g.large (burstable, unlimited credits); not a cluster.
- S3 request counts on AWS are estimates: measured per object against MinIO (dry run) × cloud object counts.
- Consumed (fetched) rate is not observable without instrumenting the systems; committed and archived rates are reported, plus the sink NIC receive rate.
- Latency resolution: LIST poll and commit poll intervals (run.json `measurement`).
