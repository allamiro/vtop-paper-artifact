# E-RQ5-PERF: VTOP v0.10.2 vs Confluent S3 Sink 12.1.15, Vector 0.61.0, Fluent Bit 5.2.0

Medians with percentile-bootstrap 95% CIs (B = 10000); differences are of medians, in % of the reference (`vtop-sha256-store`). Unresolved differences (CI includes 0) are not claimed. Warm-up runs excluded.

## Leg ap-southeast-2 (session 20261121T150129Z-apse2): 38 measured runs, 38 passing

RTT sink → S3 (TCP handshake, median of 20): 196.2 ms; broker probe: [{'host': 'vtop-eval-XXXXXXXXXXXX.s3.us-east-1.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.159.0', '16.15.160.249', '16.15.167.249', '16.15.191.185', '16.15.254.12', '52.216.211.90', '54.231.161.218', '54.231.230.226'], 'ok': 20, 'min_ms': 194.31, 'median_ms': 195.85, 'p90_ms': 198.56, 'max_ms': 198.72}, {'host': 'vtop-eval-XXXXXXXXXXXX.s3.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.183.224', '16.15.228.48', '16.15.245.25', '52.216.25.176', '52.216.25.40', '52.216.56.170', '52.217.232.50', '54.231.198.146'], 'ok': 20, 'min_ms': 193.87, 'median_ms': 196.07, 'p90_ms': 198.2, 'max_ms': 198.33}]

### Throughput (backlog drain, steady 10–90%)

Done = archived intact AND source-committed (the latency's end point); committed and archived alone are also given.

| Config | Runs | Done MiB/s | vs ref % | Committed MiB/s | Archived MiB/s | CPU s/GiB | Cores | Peak anon MiB | Objects/GiB | Raw MiB/object | Req USD/GiB (est.) | EC2 USD/GiB | Transfer USD/GiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 3 | 6.98 [6.73, 7.50] | 15.3 [9.3, 24.3] | 6.98 [6.73, 7.50] | 6.97 [6.78, 7.43] | 21.77 [20.70, 21.89] | 0.15 | 230 | 75.6 | 13.81 | 0.00082 | 0.00346 | 0.01375 |
| vtop-sha256-store | 3 | 6.05 [6.03, 6.16] | – | 6.05 [6.03, 6.16] | 6.08 [6.05, 6.17] | 21.52 [20.98, 22.74] | 0.13 | 223 | 78.4 | 13.53 | 0.00088 | 0.00398 | 0.01367 |
| vtop-blake3-readback | 3 | 5.00 [4.99, 5.09] | -17.4 [-18.9, -15.7] | 5.00 [4.99, 5.09] | 4.96 [4.93, 5.10] | 22.18 [21.99, 22.66] | 0.11 | 224 | 78.4 | 13.67 | 0.00094 | 0.00483 | 0.01677 |
| confluent | 3 | 24.89 [23.37, 24.97] | 311.1 [279.5, 313.9] | 24.56 [23.36, 24.97] | 24.86 [23.37, 25.18] | 57.82 [53.40, 62.30] | 1.41 | 953 | 63.8 | 16.24 | 0.00096 | 0.00097 | 0.01415 |
| vector | 3 | 9.24 [9.23, 9.48] | 52.6 [49.8, 57.2] | 9.37 [9.23, 9.55] | 9.35 [9.28, 9.48] | 207.77 [202.65, 209.63] | 1.88 | 567 | 63.8 | 16.25 | 0.00032 | 0.00261 | 0.01404 |
| fluentbit | 3 | 4.83 [4.83, 4.84] | -20.2 [-21.6, -19.7] | 4.83 [4.83, 4.84] | 4.83 [4.83, 4.84] | 26.23 [26.07, 26.40] | 0.12 | 141 | 61.1 | 17.10 | 0.00030 | 0.00499 | 0.01258 |

### Latency (live, fixed rate; produce → durably in S3 and offset committed)

| Config | Runs | p50 s | p90 s | p99 s | max s | object-visible p50 | commit p50 | missing |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 2 | 4.39 [4.33, 4.44] | 5.84 [5.81, 5.88] | 6.37 [6.35, 6.39] | 6.52 [6.48, 6.56] | 3.88 [3.81, 3.95] | 4.39 [4.33, 4.44] | 0 |
| vtop-sha256-store | 2 | 4.72 [4.67, 4.76] | 6.21 [6.14, 6.27] | 6.74 [6.72, 6.75] | 6.97 [6.90, 7.04] | 4.22 [4.13, 4.30] | 4.72 [4.67, 4.76] | 0 |
| vtop-blake3-readback | 2 | 6.85 [6.69, 7.02] | 8.27 [7.77, 8.76] | 9.25 [8.28, 10.23] | 9.60 [8.56, 10.63] | 5.86 [5.66, 6.07] | 6.85 [6.69, 7.02] | 0 |
| confluent | 2 | 4.17 [4.16, 4.19] | 5.80 [5.79, 5.81] | 6.21 [6.21, 6.22] | 6.39 [6.33, 6.45] | 4.14 [4.12, 4.15] | 4.03 [3.97, 4.09] | 0 |
| vector | 2 | 6.14 [6.11, 6.18] | 8.65 [8.61, 8.68] | 9.94 [9.91, 9.97] | 10.15 [10.11, 10.18] | 3.91 [3.89, 3.93] | 6.14 [6.11, 6.18] | 0 |
| fluentbit | 2 | 4.46 [4.44, 4.48] | 6.18 [6.16, 6.20] | 7.02 [6.91, 7.12] | 7.40 [7.29, 7.52] | 4.46 [4.44, 4.48] | 0.39 [0.30, 0.48] | 0 |

### Recovery after one SIGKILL (times from the kill)

| Config | Runs | ready s | first commit s | first object s | re-steady s (not reached) | duplicates | complete |
|---|---:|---:|---:|---:|---:|---|---:|
| vtop-sha256-store | 2 | 0.05 [0.05, 0.05] | 3.87 [1.24, 6.50] | 7.04 [6.52, 7.57] | 13.75 [11.50, 16.00] (0) | [0, 0] | 2/2 |
| confluent | 2 | 46.29 [43.18, 49.39] | 53.37 [50.89, 55.85] | 53.94 [51.37, 56.50] | 64.77 [57.41, 72.14] (0) | [0, 0] | 2/2 |
| vector | 2 | 0.33 [0.30, 0.36] | 15.61 [15.49, 15.73] | 7.30 [0.51, 14.09] | 25.62 [25.50, 25.74] (0) | [240000, 240000] | 2/2 |
| fluentbit | 2 | 0.27 [0.25, 0.29] | 45.30 [45.30, 45.31] | 3.54 [3.14, 3.95] | 53.81 [53.81, 53.81] (0) | [0, 0] | 2/2 |

### Correctness (oracle, every run)

| Cell | Runs | Complete | Unsafe | Lost committed | Duplicate records | Bad objects |
|---|---:|---:|---:|---:|---:|---:|
| kill/confluent | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/fluentbit | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/vector | 2 | 2 | 0 | 0 | 480000 | 0 |
| kill/vtop-sha256-store | 2 | 2 | 0 | 0 | 0 | 0 |
| live/confluent | 2 | 2 | 0 | 0 | 0 | 0 |
| live/fluentbit | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vector | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-blake3-readback | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-sha256-store | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-size-only | 2 | 2 | 0 | 0 | 0 | 0 |
| tput/confluent | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/fluentbit | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vector | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-blake3-readback | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-sha256-store | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-size-only | 3 | 3 | 0 | 0 | 0 | 0 |

## Interpretation constraints

- One instance pair per leg, one time window, t4g.large (burstable, unlimited credits); not a cluster.
- S3 request counts on AWS are estimates: measured per object against MinIO (dry run) × cloud object counts.
- Consumed (fetched) rate is not observable without instrumenting the systems; committed and archived rates are reported, plus the sink NIC receive rate.
- Latency resolution: LIST poll and commit poll intervals (run.json `measurement`).
