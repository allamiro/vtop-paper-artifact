# E-RQ5-WAN: VTOP over real long-distance links to Amazon S3 (us-east-1)

## Link (measured from the engine VM)

| Region | Instance, AZ | TCP connect RTT to the engine's S3 endpoint, median ms (start / end) | HeadBucket median ms | Native PUT / GET Mbit/s (2 MiB, one stream) | vtop-engine |
|---|---|---:|---:|---:|---|
| eu-west-1 | t4g.medium, eu-west-1a | 66.47 / 67.43 (per run 66.44) | 71.86 | 25.92 / 33.47 | 0.10.2 (0abf11696e) |
| ap-southeast-2 | t4g.medium, ap-southeast-2a | 196.43 / 196.07 (per run 196.06) | 203.90 | 9.28 / 7.66 | 0.10.2 (0abf11696e) |
| sa-east-1 | t4g.medium, sa-east-1a | 110.67 / 110.80 (per run 110.75) | 117.63 | 12.09 / 18.21 | 0.10.2 (0abf11696e) |
| ap-northeast-1 | t4g.medium, ap-northeast-1b | 147.01 / 148.72 (per run 147.93) | 149.98 | 10.86 / 9.17 | 0.10.2 (0abf11696e) |

## Native link, SSH (73.4 MB), 16 MiB batches

End-to-end MiB/s = input bytes / time until the ledger shows the last byte committed (median, bootstrap 95% CI, B = 10000). Change vs size-only: difference of medians in % with its CI.

| Region | Mode | Runs | Drain s | MiB/s [95% CI] | vs size-only % [CI] | vs us-east-1 % [CI] | CPU s | Wire tx Mbit/s | SDK retries |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| eu-west-1 | size-only | 10 | 6.05 | 11.57 [11.30, 11.88] | – | -41.7 [-44.2, -39.4] | 0.77 | 7.20 | 0 |
| eu-west-1 | sha256-store | 10 | 6.12 | 11.45 [11.05, 11.63] | -1.0 [-4.8, 1.4] | -43.1 [-45.0, -40.4] | 0.76 | 7.16 | 0 |
| eu-west-1 | blake3-readback | 10 | 7.95 | 8.81 [8.55, 9.06] | -23.8 [-27.0, -20.9] | -51.6 [-53.4, -49.7] | 0.80 | 5.56 | 0 |
| ap-southeast-2 | size-only | 10 | 10.52 | 6.66 [6.27, 6.88] | – | -66.4 [-68.8, -64.6] | 0.77 | 4.16 | 0 |
| ap-southeast-2 | sha256-store | 10 | 11.32 | 6.19 [5.74, 6.29] | -7.2 [-15.5, -1.3] | -69.3 [-71.5, -67.8] | 0.77 | 3.85 | 0 |
| ap-southeast-2 | blake3-readback | 10 | 16.23 | 4.31 [4.23, 4.38] | -35.3 [-38.4, -31.2] | -76.3 [-77.1, -75.6] | 0.82 | 2.72 | 0 |
| sa-east-1 | size-only | 10 | 7.32 | 9.57 [9.40, 9.67] | – | -51.7 [-53.7, -50.2] | 0.77 | 5.97 | 0 |
| sa-east-1 | sha256-store | 10 | 8.50 | 8.24 [8.09, 8.45] | -13.9 [-15.4, -11.3] | -59.1 [-59.9, -57.0] | 0.78 | 5.17 | 0 |
| sa-east-1 | blake3-readback | 10 | 10.49 | 6.67 [6.38, 6.74] | -30.3 [-33.5, -29.0] | -63.3 [-65.1, -62.4] | 0.85 | 4.20 | 0 |
| ap-northeast-1 | size-only | 10 | 8.77 | 7.99 [7.74, 8.09] | – | -59.7 [-61.6, -58.4] | 0.78 | 4.96 | 0 |
| ap-northeast-1 | sha256-store | 10 | 9.35 | 7.49 [7.36, 7.56] | -6.3 [-8.1, -3.5] | -62.8 [-63.6, -61.0] | 0.78 | 4.70 | 0 |
| ap-northeast-1 | blake3-readback | 10 | 12.98 | 5.39 [5.19, 5.67] | -32.5 [-34.7, -28.9] | -70.3 [-71.5, -68.8] | 0.80 | 3.42 | 0 |

## Low bandwidth: kernel shaping (tc, both directions) vs VTOP's egress cap (uploads only)

Upload body rate = object bytes / drain time; of cap = that rate in Mbit/s over the cap. Calibration = timed 2 MiB PUT/GET through the same tc shaping.

| Region | Condition | Mode | Runs | Drain s | MiB/s | Upload body Mbit/s (of cap) | Wire tx / rx Mbit/s | Calibration PUT / GET Mbit/s | SDK retries |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| eu-west-1 | tc10 | sha256-store | 3 | 8.67 | 8.07 | 4.74 (0.47) | 5.02 / 0.14 | 8.06 / 8.56 | 0 |
| eu-west-1 | tc10 | blake3-readback | 3 | 14.03 | 4.99 | 2.93 (0.29) | 3.20 / 3.20 | 8.06 / 8.56 | 0 |
| eu-west-1 | cap10 | sha256-store | 3 | 8.63 | 8.12 | 4.77 (0.48) | 5.06 / 0.10 | – / – | 0 |
| eu-west-1 | cap10 | blake3-readback | 3 | 9.86 | 7.10 | 4.17 (0.42) | 4.46 / 4.10 | – / – | 0 |
| eu-west-1 | tc2 | sha256-store | 3 | 25.16 | 2.78 | 1.64 (0.82) | 1.74 / 0.05 | 1.90 / 1.91 | 0 |
| eu-west-1 | tc2 | blake3-readback | 3 | 47.36 | 1.48 | 0.87 (0.43) | 0.95 / 0.94 | 1.90 / 1.91 | 0 |
| eu-west-1 | cap2 | sha256-store | 3 | 25.02 | 2.80 | 1.64 (0.82) | 1.77 / 0.05 | – / – | 0 |
| eu-west-1 | cap2 | blake3-readback | 3 | 26.42 | 2.65 | 1.56 (0.78) | 1.68 / 1.54 | – / – | 0 |
| ap-southeast-2 | tc10 | sha256-store | 3 | 13.78 | 5.08 | 2.99 (0.30) | 3.19 / 0.08 | 5.76 / 6.02 | 0 |
| ap-southeast-2 | tc10 | blake3-readback | 3 | 24.57 | 2.85 | 1.67 (0.17) | 1.84 / 2.01 | 5.76 / 6.02 | 0 |
| ap-southeast-2 | cap10 | sha256-store | 3 | 12.75 | 5.49 | 3.23 (0.32) | 3.42 / 0.08 | – / – | 0 |
| ap-southeast-2 | cap10 | blake3-readback | 3 | 16.92 | 4.14 | 2.43 (0.24) | 2.62 / 2.62 | – / – | 0 |
| ap-southeast-2 | tc2 | sha256-store | 3 | 30.82 | 2.27 | 1.33 (0.67) | 1.42 / 0.04 | 1.78 / 1.85 | 3 |
| ap-southeast-2 | tc2 | blake3-readback | 3 | 56.92 | 1.23 | 0.72 (0.36) | 0.80 / 0.80 | 1.78 / 1.85 | 5 |
| ap-southeast-2 | cap2 | sha256-store | 3 | 29.51 | 2.37 | 1.39 (0.70) | 1.50 / 0.04 | – / – | 0 |
| ap-southeast-2 | cap2 | blake3-readback | 3 | 32.75 | 2.14 | 1.26 (0.63) | 1.36 / 1.35 | – / – | 0 |
| sa-east-1 | tc10 | sha256-store | 3 | 10.46 | 6.69 | 3.93 (0.39) | 4.19 / 0.12 | 7.03 / 7.68 | 0 |
| sa-east-1 | tc10 | blake3-readback | 3 | 16.98 | 4.12 | 2.42 (0.24) | 2.65 / 2.75 | 7.03 / 7.68 | 0 |
| sa-east-1 | cap10 | sha256-store | 3 | 10.00 | 7.00 | 4.11 (0.41) | 4.40 / 0.09 | – / – | 0 |
| sa-east-1 | cap10 | blake3-readback | 3 | 11.97 | 5.85 | 3.44 (0.34) | 3.71 / 3.70 | – / – | 0 |
| sa-east-1 | tc2 | sha256-store | 3 | 26.76 | 2.62 | 1.54 (0.77) | 1.63 / 0.05 | 1.85 / 1.88 | 0 |
| sa-east-1 | tc2 | blake3-readback | 3 | 49.67 | 1.41 | 0.83 (0.41) | 0.91 / 0.92 | 1.85 / 1.88 | 0 |
| sa-east-1 | cap2 | sha256-store | 3 | 26.42 | 2.65 | 1.56 (0.78) | 1.67 / 0.06 | – / – | 0 |
| sa-east-1 | cap2 | blake3-readback | 3 | 29.03 | 2.41 | 1.42 (0.71) | 1.54 / 1.40 | – / – | 0 |
| ap-northeast-1 | tc10 | sha256-store | 3 | 11.80 | 5.93 | 3.48 (0.35) | 3.73 / 0.10 | 6.49 / 6.64 | 0 |
| ap-northeast-1 | tc10 | blake3-readback | 3 | 19.86 | 3.52 | 2.07 (0.21) | 2.28 / 2.42 | 6.49 / 6.64 | 0 |
| ap-northeast-1 | cap10 | sha256-store | 3 | 11.01 | 6.36 | 3.74 (0.37) | 4.00 / 0.09 | – / – | 0 |
| ap-northeast-1 | cap10 | blake3-readback | 3 | 13.76 | 5.09 | 2.99 (0.30) | 3.20 / 3.22 | – / – | 0 |
| ap-northeast-1 | tc2 | sha256-store | 3 | 28.21 | 2.48 | 1.46 (0.73) | 1.55 / 0.04 | 1.81 / 1.86 | 0 |
| ap-northeast-1 | tc2 | blake3-readback | 3 | 51.60 | 1.36 | 0.80 (0.40) | 0.88 / 0.88 | 1.81 / 1.86 | 0 |
| ap-northeast-1 | cap2 | sha256-store | 3 | 27.91 | 2.51 | 1.47 (0.74) | 1.59 / 0.05 | – / – | 0 |
| ap-northeast-1 | cap2 | blake3-readback | 3 | 30.73 | 2.28 | 1.34 (0.67) | 1.45 / 1.45 | – / – | 0 |

## Loss and jitter (netem on egress), store SHA-256

| Region | Condition | Runs | Drain s | × native drain | MiB/s | SDK retries | Failed batches |
|---|---|---:|---:|---:|---:|---:|---:|
| eu-west-1 | loss1 | 3 | 16.65 | 2.72 | 4.20 | 0 | 0 |
| eu-west-1 | loss5 | 3 | 58.37 | 9.54 | 1.20 | 0 | 0 |
| eu-west-1 | jitter | 3 | 7.82 | 1.28 | 8.95 | 0 | 0 |
| ap-southeast-2 | loss1 | 3 | 57.41 | 5.07 | 1.22 | 2 | 0 |
| ap-southeast-2 | loss5 | 3 | 138.69 | 12.25 | 0.51 | 2 | 0 |
| ap-southeast-2 | jitter | 3 | 13.32 | 1.18 | 5.26 | 0 | 0 |
| sa-east-1 | loss1 | 3 | 29.49 | 3.47 | 2.37 | 0 | 0 |
| sa-east-1 | loss5 | 3 | 78.74 | 9.26 | 0.89 | 0 | 0 |
| sa-east-1 | jitter | 3 | 9.90 | 1.16 | 7.07 | 0 | 0 |
| ap-northeast-1 | loss1 | 3 | 26.96 | 2.88 | 2.60 | 0 | 0 |
| ap-northeast-1 | loss5 | 3 | 113.05 | 12.09 | 0.62 | 0 | 0 |
| ap-northeast-1 | jitter | 3 | 12.86 | 1.38 | 5.44 | 0 | 0 |

## Partition (all egress but link-local and the VPC dropped for 60 s, mid-upload)

| Region | Committed at cut / size | Commits during cut | First commit after restore s | Tx resumed s | Drain after restore s | SDK retries | Failed batches | Complete, unsafe |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| eu-west-1 | 0 / 73417507 | 0 | 2.01 | 1.05 | 6.74 | 3 | 1 | True, 0 |
| ap-southeast-2 | 0 / 73417507 | 0 | 3.53 | 1.13 | 11.36 | 3 | 1 | True, 0 |
| sa-east-1 | 0 / 73417507 | 0 | 2.99 | 1.32 | 8.96 | 3 | 1 | True, 0 |
| ap-northeast-1 | 0 / 73417507 | 0 | 3.14 | 0.95 | 9.66 | 3 | 1 | True, 0 |

## SIGKILL during upload, then restart

| Region | Mode | Committed at kill / size | Restart to drain s | Duplicate bytes | Unreferenced objects | Committed rows sharing an object | Replays | Complete, unsafe |
|---|---|---:|---:|---:|---:|---:|---:|---|
| eu-west-1 | sha256-store | 0 / 73417507 | 6.34 | 0 | 0 | 0 | 1 | True, 0 |
| eu-west-1 | blake3-readback | 0 / 73417507 | 7.88 | 0 | 0 | 0 | 1 | True, 0 |
| ap-southeast-2 | sha256-store | 0 / 73417507 | 11.93 | 0 | 0 | 0 | 1 | True, 0 |
| ap-southeast-2 | blake3-readback | 0 / 73417507 | 15.51 | 0 | 0 | 0 | 1 | True, 0 |
| sa-east-1 | sha256-store | 0 / 73417507 | 8.41 | 0 | 0 | 0 | 1 | True, 0 |
| sa-east-1 | blake3-readback | 0 / 73417507 | 10.84 | 0 | 0 | 0 | 1 | True, 0 |
| ap-northeast-1 | sha256-store | 0 / 73417507 | 9.95 | 0 | 0 | 0 | 1 | True, 0 |
| ap-northeast-1 | blake3-readback | 0 / 73417507 | 13.20 | 0 | 0 | 0 | 1 | True, 0 |

## Policed uplink (policer at the rate shown, 5,000 B bucket; 32 MiB SSH slice, uncompressed, multipart)

Treatment = shipped deadline (300 s + body / 4,096 B/s per attempt, #663); control = fixed 120 s (request_min_bytes_per_second 10^9), 480 s window.

| Region | Arm | Committed / size | Drain s | Longest seal-to-commit s | Wire tx Mbit/s | SDK retries | Failed batches | Unsafe |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| eu-west-1 | policed (1 Mbit/s) | 33554338 / 33554338 | 391.79 | 198.23 | 0.72 | 0 | 0 | 0 |
| eu-west-1 | note | no batch took > 300 s from seal to commit: here the treatment is NOT a #663 regression check (the old fixed deadline would have passed too) | | | | | | |
| eu-west-1 | policed-fixed (1 Mbit/s) | 0 / 33554338 | – | – | 0.89 | 2 | 0 | 0 |
| ap-southeast-2 | policed (1 Mbit/s) | 33554338 / 33554338 | 608.86 | 308.19 | 0.47 | 0 | 0 | 0 |
| ap-southeast-2 | policed-fixed (1 Mbit/s) | 0 / 33554338 | – | – | 0.64 | 2 | 0 | 0 |
| sa-east-1 | policed (1 Mbit/s) | 33554338 / 33554338 | 459.49 | 229.78 | 0.62 | 0 | 0 | 0 |
| sa-east-1 | note | no batch took > 300 s from seal to commit: here the treatment is NOT a #663 regression check (the old fixed deadline would have passed too) | | | | | | |
| sa-east-1 | policed-fixed (1 Mbit/s) | 0 / 33554338 | – | – | 0.80 | 2 | 0 | 0 |
| ap-northeast-1 | policed (1 Mbit/s) | 33554338 / 33554338 | 559.84 | 299.53 | 0.50 | 0 | 0 | 0 |
| ap-northeast-1 | note | no batch took > 300 s from seal to commit: here the treatment is NOT a #663 regression check (the old fixed deadline would have passed too) | | | | | | |
| ap-northeast-1 | policed-fixed (1 Mbit/s) | 0 / 33554338 | – | – | 0.71 | 2 | 0 | 0 |

## Interpretation constraints

- One VM per region, one time window; the path to S3 is the public AWS network between regions at that time.
- Bandwidth limits and loss are emulated on the VM; the distance (RTT) is real.
- The engine cap limits upload bodies only; tc shapes both directions (read-back downloads too).
- Faults ran once per region (4 trials each across regions): they show behaviour, not rates.
- Unresolved differences (CI includes 0) are not claimed as effects.
