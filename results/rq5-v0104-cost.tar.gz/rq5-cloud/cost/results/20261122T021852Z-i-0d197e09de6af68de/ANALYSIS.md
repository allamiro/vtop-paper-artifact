# E-RQ5-COST: verification cost on EC2 + Amazon S3

Run `20261122T021852Z-i-0d197e09de6af68de`: t4g.medium in us-east-1a, AMI `ami-0697409d504dfb93d`; vtop-engine 0.10.4 (be5b419ed0658e217284e8324caaff31f39622c5), archive SHA-256 `0266c37b1f8740793f71724cddc5283c0aceb8faeda4e6bdea0d714ca8f37c84`. AWS_REQUEST_CHECKSUM_CALCULATION=`None`.
90 runs (90 passing: drained, oracle byte-exact, log/receipt/ledger/HEAD agree, single-PUT); order shuffled with seed 20261121.

Throughput is the median steady-state MiB/s (bytes at the second-to-last commit over its time) with a
percentile-bootstrap 95% CI (B = 10000). The difference is the variant median minus the size-only median,
with a bootstrap CI on the difference of medians; negative values are slowdowns. Batch sizes are measured
from the ledger (uncompressed bytes per committed batch).

| Dataset | Mode | MiB/s [95% CI] | Diff vs size-only, MiB/s [95% CI] | Change % [95% CI] | CPU s/GiB | Batches | Median batch MiB | Read-back MiB |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| SSH | size-only | 46.11 [44.82, 47.17] | 0.00 [0.00, 0.00] | 0.00% [0.00, 0.00] | 10.638 | 5 | 16.00 | 0.0 |
| SSH | sha256-store | 44.49 [43.45, 45.78] | -1.61 [-3.07, 0.04] | -3.50% [-6.56, 0.09] | 10.820 | 5 | 16.00 | 0.0 |
| SSH | blake3-readback | 38.60 [37.25, 39.63] | -7.51 [-9.30, -6.17] | -16.29% [-19.92, -13.72] | 11.299 | 5 | 16.00 | 4.9 |
| BGL | size-only | 49.70 [48.40, 50.47] | 0.00 [0.00, 0.00] | 0.00% [0.00, 0.00] | 9.914 | 45 | 16.00 | 0.0 |
| BGL | sha256-store | 48.11 [47.58, 48.88] | -1.59 [-2.60, -0.22] | -3.20% [-5.17, -0.35] | 10.010 | 45 | 16.00 | 0.0 |
| BGL | blake3-readback | 40.13 [38.38, 40.86] | -9.57 [-11.16, -8.27] | -19.25% [-22.20, -16.97] | 10.600 | 45 | 16.00 | 67.1 |
| HDFS | size-only | 49.01 [48.42, 50.02] | 0.00 [0.00, 0.00] | 0.00% [0.00, 0.00] | 10.157 | 95 | 16.00 | 0.0 |
| HDFS | sha256-store | 47.37 [46.80, 47.81] | -1.63 [-2.76, -0.93] | -3.33% [-5.59, -1.91] | 10.150 | 95 | 16.00 | 0.0 |
| HDFS | blake3-readback | 40.28 [40.02, 40.46] | -8.73 [-9.81, -8.12] | -17.80% [-19.59, -16.77] | 10.969 | 95 | 16.00 | 145.9 |

## H3.5 prediction, per dataset (CI facts only)

- SSH: store SHA-256 CI includes 0: True; BLAKE3 read-back CI below 0: True
- BGL: store SHA-256 CI includes 0: False; BLAKE3 read-back CI below 0: True
- HDFS: store SHA-256 CI includes 0: False; BLAKE3 read-back CI below 0: True

## Environment checks

- ssh/size-only: max CPU steal 0.148%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 0, max batch 16777184 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 0.0, 'commit_ms': 0.0, 'compress_ms': 47.4, 'manifest_upload_ms': 27.2, 'object_upload_ms': 67.9, 'state_write_ms': 7.2, 'total_ms': 225.7, 'verify_ms': 31.7}
- ssh/sha256-store: max CPU steal 0.148%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 0, max batch 16777184 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 0.8, 'commit_ms': 0.0, 'compress_ms': 47.5, 'manifest_upload_ms': 27.9, 'object_upload_ms': 54.3, 'state_write_ms': 7.1, 'total_ms': 231.0, 'verify_ms': 26.6}
- ssh/blake3-readback: max CPU steal 0.13%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 0, max batch 16777184 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 0.8, 'commit_ms': 0.0, 'compress_ms': 46.7, 'manifest_upload_ms': 27.8, 'object_upload_ms': 54.0, 'state_write_ms': 7.1, 'total_ms': 291.8, 'verify_ms': 86.1}
- bgl/size-only: max CPU steal 0.117%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 495, max batch 16777209 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 0.0, 'commit_ms': 0.0, 'compress_ms': 67.0778, 'manifest_upload_ms': 28.7333, 'object_upload_ms': 60.6444, 'state_write_ms': 7.1, 'total_ms': 230.1111, 'verify_ms': 28.4667}
- bgl/sha256-store: max CPU steal 0.182%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 116, max batch 16777209 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 1.2444, 'commit_ms': 0.0, 'compress_ms': 67.4778, 'manifest_upload_ms': 27.7444, 'object_upload_ms': 56.0444, 'state_write_ms': 7.1333, 'total_ms': 241.5667, 'verify_ms': 28.3778}
- bgl/blake3-readback: max CPU steal 0.157%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 353, max batch 16777209 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 1.7778, 'commit_ms': 0.0, 'compress_ms': 67.1333, 'manifest_upload_ms': 29.5889, 'object_upload_ms': 59.7556, 'state_write_ms': 7.1, 'total_ms': 310.1333, 'verify_ms': 87.1111}
- hdfs/size-only: max CPU steal 0.529%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 577, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 0.0, 'commit_ms': 0.0105, 'compress_ms': 66.4158, 'manifest_upload_ms': 28.4579, 'object_upload_ms': 58.8526, 'state_write_ms': 7.1368, 'total_ms': 232.3789, 'verify_ms': 28.3105}
- hdfs/sha256-store: max CPU steal 0.09%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 263, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 1.1579, 'commit_ms': 0.0, 'compress_ms': 66.8105, 'manifest_upload_ms': 28.0789, 'object_upload_ms': 57.3053, 'state_write_ms': 7.2053, 'total_ms': 247.4211, 'verify_ms': 28.6579}
- hdfs/blake3-readback: max CPU steal 0.11%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 1027, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 1.9211, 'commit_ms': 0.0895, 'compress_ms': 67.7421, 'manifest_upload_ms': 27.8632, 'object_upload_ms': 57.8368, 'state_write_ms': 7.1842, 'total_ms': 305.7895, 'verify_ms': 85.8632}

## Interpretation constraints

- One instance, one AZ, one time window; not a distributed deployment.
- Stage timings are reported only if the engine logged them (v0.10.2 #843); absent is not zero.
- Unresolved differences (CI includes 0) are not claimed as effects.
