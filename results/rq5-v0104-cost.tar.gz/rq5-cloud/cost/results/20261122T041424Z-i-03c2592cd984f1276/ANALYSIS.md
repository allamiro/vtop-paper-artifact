# E-RQ5-COST: verification cost on EC2 + Amazon S3

Run `20261122T041424Z-i-03c2592cd984f1276`: t4g.large in us-east-1a, AMI `ami-0697409d504dfb93d`; vtop-engine 0.10.4 (be5b419ed0658e217284e8324caaff31f39622c5), archive SHA-256 `0266c37b1f8740793f71724cddc5283c0aceb8faeda4e6bdea0d714ca8f37c84`. AWS_REQUEST_CHECKSUM_CALCULATION=`None`.
30 runs (30 passing: drained, oracle byte-exact, log/receipt/ledger/HEAD agree, single-PUT); order shuffled with seed 20261121.

Throughput is the median steady-state MiB/s (bytes at the second-to-last commit over its time) with a
percentile-bootstrap 95% CI (B = 10000). The difference is the variant median minus the size-only median,
with a bootstrap CI on the difference of medians; negative values are slowdowns. Batch sizes are measured
from the ledger (uncompressed bytes per committed batch).

| Dataset | Mode | MiB/s [95% CI] | Diff vs size-only, MiB/s [95% CI] | Change % [95% CI] | CPU s/GiB | Batches | Median batch MiB | Read-back MiB |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| HDFS | size-only | 47.03 [46.80, 48.05] | 0.00 [0.00, 0.00] | 0.00% [0.00, 0.00] | 10.541 | 95 | 16.00 | 0.0 |
| HDFS | sha256-store | 45.21 [44.52, 46.17] | -1.82 [-3.04, -0.98] | -3.88% [-6.36, -1.93] | 10.601 | 95 | 16.00 | 0.0 |
| HDFS | blake3-readback | 38.12 [37.44, 38.70] | -8.91 [-10.11, -8.31] | -18.95% [-21.16, -17.68] | 11.387 | 95 | 16.00 | 145.9 |

## H3.5 prediction, per dataset (CI facts only)

- HDFS: store SHA-256 CI includes 0: False; BLAKE3 read-back CI below 0: True

## Environment checks

- hdfs/size-only: max CPU steal 1.106%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 496, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 0.0, 'commit_ms': 0.0316, 'compress_ms': 70.4421, 'manifest_upload_ms': 29.2368, 'object_upload_ms': 60.3579, 'state_write_ms': 7.5632, 'total_ms': 238.7737, 'verify_ms': 27.8474}
- hdfs/sha256-store: max CPU steal 1.211%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 407, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 1.1947, 'commit_ms': 0.0526, 'compress_ms': 70.4211, 'manifest_upload_ms': 28.6842, 'object_upload_ms': 58.7263, 'state_write_ms': 7.5684, 'total_ms': 254.9842, 'verify_ms': 28.6632}
- hdfs/blake3-readback: max CPU steal 1.109%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 1105, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'checksum_ms': 1.9579, 'commit_ms': 0.0263, 'compress_ms': 70.5579, 'manifest_upload_ms': 28.8, 'object_upload_ms': 60.0316, 'state_write_ms': 7.4368, 'total_ms': 320.9368, 'verify_ms': 90.8211}

## Interpretation constraints

- One instance, one AZ, one time window; not a distributed deployment.
- Stage timings are reported only if the engine logged them (v0.10.2 #843); absent is not zero.
- Unresolved differences (CI includes 0) are not claimed as effects.
