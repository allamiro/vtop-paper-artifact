# E-RQ5-PERF: VTOP v0.10.2 vs Confluent S3 Sink 12.1.15, Vector 0.61.0, Fluent Bit 5.2.0

Medians with percentile-bootstrap 95% CIs (B = 10000); differences are of medians, in % of the reference (`vtop-sha256-store`). Unresolved differences (CI includes 0) are not claimed. Warm-up runs excluded.

## Leg us-east-1 (session 20261122T041404Z-use1): 105 measured runs, 105 passing

RTT sink → S3 (TCP handshake, median of 20): 0.45 ms; broker probe: [{'host': 'vtop-eval-XXXXXXXXXXXX.s3.us-east-1.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.213.196', '16.15.213.27', '16.15.245.26', '52.216.40.138', '52.217.84.48', '54.231.160.218', '54.231.163.250', '54.231.194.34'], 'ok': 20, 'min_ms': 0.45, 'median_ms': 0.64, 'p90_ms': 0.7, 'max_ms': 0.7}, {'host': 'vtop-eval-XXXXXXXXXXXX.s3.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.157.178', '16.15.161.166', '16.15.212.20', '16.15.212.234', '16.15.244.38', '16.15.253.236', '52.217.193.226', '52.217.229.10'], 'ok': 20, 'min_ms': 0.3, 'median_ms': 0.63, 'p90_ms': 0.85, 'max_ms': 1.19}]

### Throughput (backlog drain, steady 10–90%)

Done = archived intact AND source-committed (the latency's end point); committed and archived alone are also given.

| Config | Runs | Done MiB/s | vs ref % | Committed MiB/s | Archived MiB/s | CPU s/GiB | Cores | Peak anon MiB | Objects/GiB | Raw MiB/object | Req USD/GiB (est.) | EC2 USD/GiB | Transfer USD/GiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 5 | 24.56 [23.32, 27.40] | 6.4 [-2.2, 23.2] | 24.85 [23.08, 27.55] | 24.56 [23.64, 26.78] | 24.56 [24.01, 25.02] | 0.60 | 228 | 76.3 | 13.65 | 0.00082 | 0.00078 | 0.00000 |
| vtop-sha256-store | 5 | 23.09 [21.10, 25.03] | – | 23.01 [20.89, 25.14] | 23.61 [21.10, 25.03] | 23.96 [23.01, 24.77] | 0.54 | 220 | 77.0 | 13.64 | 0.00086 | 0.00083 | 0.00000 |
| vtop-blake3-readback | 5 | 22.75 [19.93, 26.29] | -1.5 [-15.7, 13.9] | 22.95 [20.10, 26.58] | 22.75 [19.90, 26.25] | 25.28 [23.51, 25.67] | 0.56 | 224 | 77.0 | 13.75 | 0.00092 | 0.00084 | 0.00000 |
| vtop-sha256-gzip6 | 5 | 16.94 [15.91, 17.89] | -26.6 [-33.3, -19.2] | 16.82 [15.85, 18.02] | 17.00 [15.91, 17.89] | 49.81 [48.88, 50.42] | 0.81 | 207 | 76.3 | 13.80 | 0.00085 | 0.00113 | 0.00000 |
| confluent | 5 | 37.82 [36.33, 38.77] | 63.8 [51.1, 79.2] | 37.59 [36.60, 39.09] | 37.72 [36.53, 39.02] | 53.10 [51.93, 54.99] | 1.96 | 1013 | 63.8 | 16.24 | 0.00096 | 0.00051 | 0.00000 |
| vector | 5 | 9.48 [9.36, 10.03] | -58.9 [-62.1, -54.7] | 9.62 [9.24, 10.03] | 9.44 [9.36, 10.09] | 203.79 [192.88, 205.75] | 1.89 | 560 | 63.8 | 16.26 | 0.00032 | 0.00201 | 0.00000 |
| fluentbit | 5 | 4.83 [4.83, 4.85] | -79.1 [-80.7, -77.1] | 4.84 [4.83, 4.84] | 4.83 [4.83, 4.85] | 26.30 [25.97, 26.43] | 0.12 | 132 | 61.1 | 17.09 | 0.00030 | 0.00395 | 0.00000 |

### Latency (live, fixed rate; produce → durably in S3 and offset committed)

| Config | Runs | p50 s | p90 s | p99 s | max s | object-visible p50 | commit p50 | missing |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 3 | 2.73 [2.73, 2.77] | 4.24 [4.23, 4.26] | 4.69 [4.65, 4.70] | 4.90 [4.77, 4.93] | 2.71 [2.67, 2.72] | 2.65 [2.63, 2.66] | 0 |
| vtop-sha256-store | 3 | 2.70 [2.70, 2.81] | 4.23 [4.23, 4.33] | 4.68 [4.65, 4.78] | 4.89 [4.88, 4.97] | 2.67 [2.65, 2.76] | 2.59 [2.58, 2.68] | 0 |
| vtop-blake3-readback | 3 | 2.81 [2.76, 2.90] | 4.33 [4.30, 4.45] | 4.79 [4.73, 4.86] | 4.97 [4.91, 5.01] | 2.75 [2.64, 2.81] | 2.75 [2.74, 2.80] | 0 |
| confluent | 3 | 2.68 [2.66, 2.68] | 4.28 [4.26, 4.28] | 4.64 [4.62, 4.64] | 4.69 [4.68, 4.70] | 2.44 [2.42, 2.57] | 2.68 [2.66, 2.68] | 0 |
| vector | 3 | 5.16 [5.14, 5.19] | 7.66 [7.64, 7.70] | 8.96 [8.94, 9.00] | 9.17 [9.15, 9.20] | 2.67 [2.65, 2.68] | 5.16 [5.14, 5.19] | 0 |
| fluentbit | 3 | 3.18 [2.89, 3.19] | 4.79 [4.49, 4.87] | 5.40 [5.11, 5.43] | 5.53 [5.24, 5.83] | 3.18 [2.89, 3.19] | 0.32 [0.29, 0.48] | 0 |

### Recovery after one SIGKILL (times from the kill)

| Config | Runs | ready s | first commit s | first object s | re-steady s (not reached) | duplicates | complete |
|---|---:|---:|---:|---:|---:|---|---:|
| vtop-sha256-store | 3 | 0.05 [0.05, 0.05] | 1.70 [1.49, 1.99] | 0.73 [0.21, 1.72] | 13.50 [10.76, 21.99] (0) | [0, 0, 0] | 3/3 |
| confluent | 3 | 45.25 [45.24, 45.77] | 50.10 [49.88, 50.86] | 50.82 [49.85, 51.09] | 58.36 [58.14, 59.12] (0) | [0, 0, 0] | 3/3 |
| vector | 3 | 0.33 [0.31, 0.35] | 10.73 [10.48, 15.47] | 9.71 [0.45, 9.73] | 25.48 [20.49, 25.74] (0) | [168529, 0, 240000] | 3/3 |
| fluentbit | 3 | 0.30 [0.27, 0.32] | 45.28 [45.27, 45.51] | 0.98 [0.71, 1.19] | 53.79 [53.54, 54.02] (0) | [0, 0, 0] | 3/3 |

### Storage faults on S3 (cloud counterpart of RQ4; native overwrite/delete, no proxy)

Class = when the damage landed relative to the sink's first commit into the damaged object's records (`damage_before_commit` and `commit_before_object_visible` are the RQ4-comparable cases).

| Fault/config | Trials | Classes | Unsafe (all) | Unsafe (RQ4-comparable / n) | Lost committed records | Complete | VTOP vs its verification | VTOP scrub/audit rc |
|---|---:|---|---:|---:|---|---:|---|---|
| corrupt/vtop-blake3-readback | 5 | {'ambiguous_within_one_poll': 4, 'damage_after_commit': 1} | 5 | 0 / 0 | [38176, 39058, 39003, 39498, 39058] | 0 | {'after_verification': 4, 'before_verification': 1} | [1, 1, 1, 1, 1] / [0, 0, 0, 0, 0] |
| corrupt/confluent | 5 | {'ambiguous_within_one_poll': 2, 'damage_before_commit': 3} | 5 | 3 / 3 | [40000, 40000, 40000, 40000, 40000] | 0 | – | – / – |
| corrupt/vector | 5 | {'damage_before_commit': 5} | 5 | 5 / 5 | [40000, 40000, 40000, 40000, 40000] | 0 | – | – / – |
| corrupt/fluentbit | 5 | {'commit_before_object_visible': 5} | 5 | 5 / 5 | [42378, 42991, 42486, 42486, 41202] | 0 | – | – / – |
| lost/vtop-blake3-readback | 5 | {'damage_after_commit': 1, 'ambiguous_within_one_poll': 4} | 5 | 0 / 0 | [39003, 39498, 39498, 38176, 38176] | 0 | {'after_verification': 4, 'before_verification': 1} | [1, 1, 1, 1, 1] / [1, 1, 1, 1, 1] |
| lost/confluent | 5 | {'damage_before_commit': 3, 'ambiguous_within_one_poll': 2} | 5 | 3 / 3 | [40000, 40000, 40000, 40000, 40000] | 0 | – | – / – |
| lost/vector | 5 | {'damage_before_commit': 5} | 5 | 5 / 5 | [40000, 40000, 40000, 40000, 40000] | 0 | – | – / – |
| lost/fluentbit | 5 | {'commit_before_object_visible': 5} | 5 | 5 / 5 | [41202, 42486, 41202, 42486, 42378] | 0 | – | – / – |

### Correctness (oracle, every run)

| Cell | Runs | Complete | Unsafe | Lost committed | Duplicate records | Bad objects |
|---|---:|---:|---:|---:|---:|---:|
| corrupt/confluent | 5 | 0 | 5 | 200000 | 0 | 5 |
| corrupt/fluentbit | 5 | 0 | 5 | 211543 | 0 | 5 |
| corrupt/vector | 5 | 0 | 5 | 200000 | 0 | 5 |
| corrupt/vtop-blake3-readback | 5 | 0 | 5 | 194793 | 0 | 5 |
| kill/confluent | 3 | 3 | 0 | 0 | 0 | 0 |
| kill/fluentbit | 3 | 3 | 0 | 0 | 0 | 0 |
| kill/vector | 3 | 3 | 0 | 0 | 408529 | 0 |
| kill/vtop-sha256-store | 3 | 3 | 0 | 0 | 0 | 0 |
| live/confluent | 3 | 3 | 0 | 0 | 0 | 0 |
| live/fluentbit | 3 | 3 | 0 | 0 | 0 | 0 |
| live/vector | 3 | 3 | 0 | 0 | 0 | 0 |
| live/vtop-blake3-readback | 3 | 3 | 0 | 0 | 0 | 0 |
| live/vtop-sha256-store | 3 | 3 | 0 | 0 | 0 | 0 |
| live/vtop-size-only | 3 | 3 | 0 | 0 | 0 | 0 |
| lost/confluent | 5 | 0 | 5 | 200000 | 0 | 0 |
| lost/fluentbit | 5 | 0 | 5 | 209754 | 0 | 0 |
| lost/vector | 5 | 0 | 5 | 200000 | 0 | 0 |
| lost/vtop-blake3-readback | 5 | 0 | 5 | 194351 | 0 | 0 |
| tput/confluent | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/fluentbit | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vector | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vtop-blake3-readback | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vtop-sha256-gzip6 | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vtop-sha256-store | 5 | 5 | 0 | 0 | 0 | 0 |
| tput/vtop-size-only | 5 | 5 | 0 | 0 | 0 | 0 |

## Leg ap-southeast-2 (session 20261122T032729Z-apse2): 38 measured runs, 38 passing

RTT sink → S3 (TCP handshake, median of 20): 196.43 ms; broker probe: [{'host': 'vtop-eval-XXXXXXXXXXXX.s3.us-east-1.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.207.169', '16.15.214.149', '16.15.244.89', '16.15.255.117', '16.182.104.66', '16.182.17.178', '16.182.68.130', '54.231.226.154'], 'ok': 20, 'min_ms': 193.76, 'median_ms': 196.12, 'p90_ms': 198.22, 'max_ms': 198.31}, {'host': 'vtop-eval-XXXXXXXXXXXX.s3.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.174.205', '16.15.183.75', '16.15.199.253', '16.15.252.207', '16.182.40.26', '52.217.201.82', '54.231.130.186', '54.231.137.66'], 'ok': 20, 'min_ms': 193.75, 'median_ms': 196.3, 'p90_ms': 198.2, 'max_ms': 198.32}]

### Throughput (backlog drain, steady 10–90%)

Done = archived intact AND source-committed (the latency's end point); committed and archived alone are also given.

| Config | Runs | Done MiB/s | vs ref % | Committed MiB/s | Archived MiB/s | CPU s/GiB | Cores | Peak anon MiB | Objects/GiB | Raw MiB/object | Req USD/GiB (est.) | EC2 USD/GiB | Transfer USD/GiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 3 | 8.70 [8.18, 9.41] | 22.7 [8.9, 39.1] | 8.70 [8.18, 9.41] | 8.82 [8.18, 9.31] | 23.87 [22.95, 24.90] | 0.21 | 235 | 77.0 | 13.72 | 0.00083 | 0.00277 | 0.01375 |
| vtop-sha256-store | 3 | 7.09 [6.76, 7.52] | – | 7.09 [6.76, 7.52] | 7.09 [6.77, 7.51] | 23.95 [22.73, 24.12] | 0.16 | 228 | 77.0 | 13.81 | 0.00086 | 0.00340 | 0.01379 |
| vtop-blake3-readback | 3 | 5.27 [5.07, 5.63] | -25.6 [-32.5, -16.8] | 5.27 [5.07, 5.63] | 5.27 [5.08, 5.59] | 24.46 [24.04, 24.55] | 0.13 | 219 | 79.1 | 13.65 | 0.00095 | 0.00457 | 0.01653 |
| confluent | 3 | 25.90 [25.33, 26.33] | 265.3 [237.0, 289.1] | 25.96 [25.39, 26.38] | 26.65 [25.33, 26.69] | 55.79 [52.67, 60.13] | 1.43 | 1130 | 63.8 | 16.24 | 0.00096 | 0.00093 | 0.01417 |
| vector | 3 | 9.35 [9.22, 9.62] | 31.9 [22.6, 42.1] | 9.35 [9.22, 9.62] | 9.33 [9.14, 9.63] | 207.33 [202.41, 210.45] | 1.89 | 573 | 63.8 | 16.26 | 0.00032 | 0.00258 | 0.01376 |
| fluentbit | 3 | 4.84 [4.83, 4.84] | -31.8 [-35.8, -28.5] | 4.84 [4.83, 4.84] | 4.84 [4.83, 4.84] | 26.22 [26.16, 26.31] | 0.12 | 144 | 61.1 | 17.09 | 0.00030 | 0.00499 | 0.01259 |

### Latency (live, fixed rate; produce → durably in S3 and offset committed)

| Config | Runs | p50 s | p90 s | p99 s | max s | object-visible p50 | commit p50 | missing |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 2 | 4.45 [4.43, 4.47] | 5.97 [5.96, 5.99] | 6.65 [6.60, 6.69] | 7.02 [7.00, 7.04] | 3.94 [3.86, 4.02] | 4.45 [4.43, 4.46] | 0 |
| vtop-sha256-store | 2 | 4.70 [4.64, 4.75] | 6.13 [6.11, 6.15] | 6.76 [6.75, 6.77] | 7.00 [6.99, 7.01] | 4.20 [4.19, 4.21] | 4.70 [4.64, 4.75] | 0 |
| vtop-blake3-readback | 2 | 6.74 [6.74, 6.74] | 8.12 [7.89, 8.35] | 9.61 [9.21, 10.01] | 10.01 [9.61, 10.41] | 5.76 [5.72, 5.80] | 6.74 [6.74, 6.74] | 0 |
| confluent | 2 | 4.18 [4.16, 4.20] | 5.82 [5.82, 5.82] | 6.25 [6.22, 6.28] | 6.43 [6.36, 6.50] | 4.12 [4.09, 4.15] | 4.07 [4.03, 4.11] | 0 |
| vector | 2 | 6.13 [6.10, 6.16] | 8.63 [8.60, 8.66] | 9.93 [9.90, 9.96] | 10.14 [10.11, 10.17] | 3.85 [3.81, 3.89] | 6.13 [6.10, 6.16] | 0 |
| fluentbit | 2 | 4.52 [4.51, 4.54] | 6.31 [6.29, 6.33] | 7.11 [7.09, 7.14] | 7.51 [7.49, 7.54] | 4.52 [4.51, 4.54] | 0.43 [0.37, 0.48] | 0 |

### Recovery after one SIGKILL (times from the kill)

| Config | Runs | ready s | first commit s | first object s | re-steady s (not reached) | duplicates | complete |
|---|---:|---:|---:|---:|---:|---|---:|
| vtop-sha256-store | 2 | 0.05 [0.05, 0.05] | 5.62 [5.00, 6.25] | 6.69 [5.65, 7.72] | 11.76 [11.25, 12.27] (0) | [0, 0] | 2/2 |
| confluent | 2 | 43.91 [43.69, 44.13] | 51.16 [50.38, 51.94] | 51.46 [50.79, 52.13] | 62.67 [61.70, 63.64] (0) | [0, 0] | 2/2 |
| vector | 2 | 0.31 [0.31, 0.32] | 15.52 [15.50, 15.54] | 14.45 [14.24, 14.66] | 28.02 [25.51, 30.54] (0) | [0, 0] | 2/2 |
| fluentbit | 2 | 0.27 [0.26, 0.28] | 45.30 [45.29, 45.30] | 3.75 [3.57, 3.94] | 53.80 [53.80, 53.80] (0) | [0, 0] | 2/2 |

### Correctness (oracle, every run)

| Cell | Runs | Complete | Unsafe | Lost committed | Duplicate records | Bad objects |
|---|---:|---:|---:|---:|---:|---:|
| kill/confluent | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/fluentbit | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/vector | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/vtop-sha256-store | 2 | 2 | 0 | 0 | 0 | 0 |
| live/confluent | 2 | 2 | 0 | 0 | 0 | 0 |
| live/fluentbit | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vector | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-blake3-readback | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-sha256-store | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-size-only | 2 | 2 | 0 | 0 | 0 | 0 |
| tput/confluent | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/fluentbit | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vector | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-blake3-readback | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-sha256-store | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-size-only | 3 | 3 | 0 | 0 | 0 | 0 |

## Distance effect (far leg vs us-east-1)

| Config | Done MiB/s change % | Live p50 change s |
|---|---:|---:|
| vtop-size-only | -64.6 [-68.5, -61.6] | 1.72 [1.66, 1.74] |
| vtop-sha256-store | -69.3 [-71.8, -66.1] | 2.00 [1.84, 2.05] |
| vtop-blake3-readback | -76.8 [-79.9, -73.3] | 3.93 [3.84, 3.98] |
| confluent | -31.5 [-34.5, -28.7] | 1.50 [1.48, 1.54] |
| vector | -1.4 [-6.7, 2.8] | 0.98 [0.91, 1.02] |
| fluentbit | 0.1 [-0.4, 0.1] | 1.35 [1.32, 1.65] |

## Interpretation constraints

- One instance pair per leg, one time window, t4g.large (burstable, unlimited credits); not a cluster.
- S3 request counts on AWS are estimates: measured per object against MinIO (dry run) × cloud object counts.
- Consumed (fetched) rate is not observable without instrumenting the systems; committed and archived rates are reported, plus the sink NIC receive rate.
- Latency resolution: LIST poll and commit poll intervals (run.json `measurement`).
