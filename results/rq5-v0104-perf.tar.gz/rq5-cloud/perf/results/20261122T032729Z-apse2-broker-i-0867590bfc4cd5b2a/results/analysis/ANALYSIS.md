# E-RQ5-PERF: VTOP v0.10.2 vs Confluent S3 Sink 12.1.15, Vector 0.61.0, Fluent Bit 5.2.0

Medians with percentile-bootstrap 95% CIs (B = 10000); differences are of medians, in % of the reference (`vtop-sha256-store`). Unresolved differences (CI includes 0) are not claimed. Warm-up runs excluded.

## Leg ap-southeast-2 (session 20261122T032729Z-apse2): 38 measured runs, 38 passing

RTT sink → S3 (TCP handshake, median of 20): 196.43 ms; broker probe: [{'host': 'vtop-eval-XXXXXXXXXXXX.s3.us-east-1.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.207.169', '16.15.214.149', '16.15.244.89', '16.15.255.117', '16.182.104.66', '16.182.17.178', '16.182.68.130', '54.231.226.154'], 'ok': 20, 'min_ms': 193.76, 'median_ms': 196.12, 'p90_ms': 198.22, 'max_ms': 198.31}, {'host': 'vtop-eval-XXXXXXXXXXXX.s3.amazonaws.com', 'port': 443, 'n': 20, 'addresses': ['16.15.174.205', '16.15.183.75', '16.15.199.253', '16.15.252.207', '16.182.40.26', '52.217.201.82', '54.231.130.186', '54.231.137.66'], 'ok': 20, 'min_ms': 193.75, 'median_ms': 196.3, 'p90_ms': 198.2, 'max_ms': 198.32}]

### Throughput (backlog drain, steady 10–90%)

Done = archived intact AND source-committed (the latency's end point); committed and archived alone are also given.

| Config | Runs | Done MiB/s | vs ref % | Committed MiB/s | Archived MiB/s | CPU s/GiB | Cores | Peak anon MiB | Objects/GiB | Raw MiB/object | Req USD/GiB (est.) | EC2 USD/GiB | Transfer USD/GiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 3 | 8.70 [8.18, 9.41] | 22.7 [8.9, 39.1] | 8.70 [8.18, 9.41] | 8.82 [8.18, 9.31] | 23.87 [22.95, 24.90] | 0.21 | 235 | 77.0 | 13.72 | 0.00083 | 0.00277 | 0.01375 |
| vtop-sha256-store | 3 | 7.09 [6.76, 7.52] | – | 7.09 [6.76, 7.52] | 7.09 [6.77, 7.51] | 23.95 [22.73, 24.12] | 0.16 | 228 | 77.0 | 13.81 | 0.00086 | 0.00340 | 0.01379 |
| vtop-blake3-readback | 3 | 5.27 [5.07, 5.63] | -25.6 [-32.5, -16.8] | 5.27 [5.07, 5.63] | 5.27 [5.08, 5.59] | 24.46 [24.04, 24.55] | 0.13 | 219 | 79.1 | 13.65 | 0.00095 | 0.00457 | 0.01653 |
| confluent | 3 | 25.90 [25.33, 26.33] | 265.3 [237.0, 289.1] | 25.96 [25.39, 26.38] | 26.65 [25.33, 26.69] | 55.79 [52.67, 60.13] | 1.43 | 1130 | 63.8 | 16.24 | 0.00096 | 0.00093 | 0.01417 |
| vector | 3 | 9.35 [9.22, 9.62] | 31.9 [22.6, 42.1] | 9.35 [9.22, 9.62] | 9.33 [9.14, 9.63] | 207.33 [202.41, 210.45] | 1.89 | 573 | 63.8 | 16.26 | 0.00032 | 0.00258 | 0.01376 |
| fluentbit | 3 | 4.84 [4.83, 4.84] | -31.8 [-35.8, -28.5] | 4.84 [4.83, 4.84] | 4.84 [4.83, 4.84] | 26.22 [26.16, 26.31] | 0.12 | 144 | 61.1 | 17.09 | 0.00030 | 0.00499 | 0.01259 |

### Latency (live, fixed rate; produce → durably in S3 and offset committed)

| Config | Runs | p50 s | p90 s | p99 s | max s | object-visible p50 | commit p50 | missing |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| vtop-size-only | 2 | 4.45 [4.43, 4.47] | 5.97 [5.96, 5.99] | 6.65 [6.60, 6.69] | 7.02 [7.00, 7.04] | 3.94 [3.86, 4.02] | 4.45 [4.43, 4.46] | 0 |
| vtop-sha256-store | 2 | 4.70 [4.64, 4.75] | 6.13 [6.11, 6.15] | 6.76 [6.75, 6.77] | 7.00 [6.99, 7.01] | 4.20 [4.19, 4.21] | 4.70 [4.64, 4.75] | 0 |
| vtop-blake3-readback | 2 | 6.74 [6.74, 6.74] | 8.12 [7.89, 8.35] | 9.61 [9.21, 10.01] | 10.01 [9.61, 10.41] | 5.76 [5.72, 5.80] | 6.74 [6.74, 6.74] | 0 |
| confluent | 2 | 4.18 [4.16, 4.20] | 5.82 [5.82, 5.82] | 6.25 [6.22, 6.28] | 6.43 [6.36, 6.50] | 4.12 [4.09, 4.15] | 4.07 [4.03, 4.11] | 0 |
| vector | 2 | 6.13 [6.10, 6.16] | 8.63 [8.60, 8.66] | 9.93 [9.90, 9.96] | 10.14 [10.11, 10.17] | 3.85 [3.81, 3.89] | 6.13 [6.10, 6.16] | 0 |
| fluentbit | 2 | 4.52 [4.51, 4.54] | 6.31 [6.29, 6.33] | 7.11 [7.09, 7.14] | 7.51 [7.49, 7.54] | 4.52 [4.51, 4.54] | 0.43 [0.37, 0.48] | 0 |

### Recovery after one SIGKILL (times from the kill)

| Config | Runs | ready s | first commit s | first object s | re-steady s (not reached) | duplicates | complete |
|---|---:|---:|---:|---:|---:|---|---:|
| vtop-sha256-store | 2 | 0.05 [0.05, 0.05] | 5.62 [5.00, 6.25] | 6.69 [5.65, 7.72] | 11.76 [11.25, 12.27] (0) | [0, 0] | 2/2 |
| confluent | 2 | 43.91 [43.69, 44.13] | 51.16 [50.38, 51.94] | 51.46 [50.79, 52.13] | 62.67 [61.70, 63.64] (0) | [0, 0] | 2/2 |
| vector | 2 | 0.31 [0.31, 0.32] | 15.52 [15.50, 15.54] | 14.45 [14.24, 14.66] | 28.02 [25.51, 30.54] (0) | [0, 0] | 2/2 |
| fluentbit | 2 | 0.27 [0.26, 0.28] | 45.30 [45.29, 45.30] | 3.75 [3.57, 3.94] | 53.80 [53.80, 53.80] (0) | [0, 0] | 2/2 |

### Correctness (oracle, every run)

| Cell | Runs | Complete | Unsafe | Lost committed | Duplicate records | Bad objects |
|---|---:|---:|---:|---:|---:|---:|
| kill/confluent | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/fluentbit | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/vector | 2 | 2 | 0 | 0 | 0 | 0 |
| kill/vtop-sha256-store | 2 | 2 | 0 | 0 | 0 | 0 |
| live/confluent | 2 | 2 | 0 | 0 | 0 | 0 |
| live/fluentbit | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vector | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-blake3-readback | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-sha256-store | 2 | 2 | 0 | 0 | 0 | 0 |
| live/vtop-size-only | 2 | 2 | 0 | 0 | 0 | 0 |
| tput/confluent | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/fluentbit | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vector | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-blake3-readback | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-sha256-store | 3 | 3 | 0 | 0 | 0 | 0 |
| tput/vtop-size-only | 3 | 3 | 0 | 0 | 0 | 0 |

## Interpretation constraints

- One instance pair per leg, one time window, t4g.large (burstable, unlimited credits); not a cluster.
- S3 request counts on AWS are estimates: measured per object against MinIO (dry run) × cloud object counts.
- Consumed (fetched) rate is not observable without instrumenting the systems; committed and archived rates are reported, plus the sink NIC receive rate.
- Latency resolution: LIST poll and commit poll intervals (run.json `measurement`).
