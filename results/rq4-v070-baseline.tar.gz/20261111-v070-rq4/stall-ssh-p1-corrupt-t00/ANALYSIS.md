# Kafka partition stall in E-RQ4-B trial vtop/ssh-p1/corrupt/t00 (VTOP v0.7.0)

Analysis by the vtop-engine maintainers from this bundle (read-only), 2026-11-11; tracked as vtop-engine
issue #623, fix in PR #644 (open).

- Two read passes filled the first batch (37,622 and 39,432 records); each ended exactly at the 4 MiB batch
  budget, so the partition was paused at the end of each pass.
- The batch committed (`commit_at=77054`). After that, 1,036 cycles over more than 10.5 minutes read 0
  records; the log has no seek, pause/resume, poll or error lines.
- So the single partition, held at the concrete offset 77,054, stopped delivering after a pause/resume.
  v0.7.0 never re-assigns a partition held at a concrete offset, so only a restart clears it. Why its
  fetcher stopped is not in the log (v0.7.0 does not log assign/pause/resume).
- Not reproduced naturally in six further attempts (each recovered within ~1 s): intermittent.
- Safety: the group offset stayed at 77,054 and nothing beyond it was acknowledged. A liveness failure,
  not loss.
- PR #644 detects a per-partition stall and restarts that partition (a second stall at the same high
  watermark rebuilds the consumer). A live test shaped like this run fails on main and passes on #644.

## All four stalled VTOP trials (vtop-engine maintainers, read-only, 2026-11-11)

Same mechanism in every run: each productive read pass stopped 20-156 bytes short of the 4 MiB budget
(less than one record), so it ended by rejecting a record; that pauses the partition and forces a fresh
`assign()` at a concrete offset on the next pass; after the last such re-assign every cycle reads
nothing, with no seek or poll error.

| Trial | Last productive pass | Committed through | Zero-read cycles after it |
|---|---|---|---|
| corrupt t00 (pre-fault) | 4,194,252 B | 77,054 | 1,476 |
| corrupt t01 (pre-fault) | 4,194,284 B | 116,058 | 1,479 |
| corrupt t09 (after a BLAKE3-mismatch rewind) | 4,194,284 B | 37,622 | 1,416 |
| lost t01 (after the injected loss) | 4,194,224 B | 310,456 | 1,423 |

The injected faults preceded the stalls and do not change the kind of stall. PR #644 detects all four
(an idle partition whose high watermark is past its read position): it restarts that partition and
rebuilds the consumer if the stall recurs.

Limit: the trigger inside librdkafka or the broker is not identified. A private Kafka 3.9.1 loop with the
same shape (300 cycles across 50 groups) and 7 runs of the v0.7.0 binary did not stall outside this
environment. The mechanism is established from logs; the trigger is not.
