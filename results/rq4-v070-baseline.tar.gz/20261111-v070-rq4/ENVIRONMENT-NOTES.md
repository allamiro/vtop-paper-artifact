# Environment notes for E-RQ4-B (20261111-v070-rq4)

- Host shared during this campaign: the vtop-engine work on the same machine was running its
  #483 TCP baseline measurement concurrently (reported 2026-11-11 while this run was in progress).
  Elapsed times (`elapsed_s`) in `trials.jsonl` are therefore noisy and are **not** used as a
  performance result. The outcomes this experiment reports are safety outcomes from the oracle
  (unsafe commits, committed records without an intact copy, completeness, duplicates); they do
  not depend on timing.
- The S3 fault proxy is a Python process on the host and buffers each request body; it slows both
  systems. Another reason not to read the elapsed times as throughput.
