# E-RQ5-WAN: VTOP over real long-distance links to Amazon S3 (us-east-1)

## Link (measured from the engine VM)

| Region | Instance, AZ | TCP connect RTT to the engine's S3 endpoint, median ms (start / end) | HeadBucket median ms | Native PUT / GET Mbit/s (2 MiB, one stream) | vtop-engine |
|---|---|---:|---:|---:|---|
| eu-west-1 | t4g.medium, eu-west-1a | 67.33 / 66.93 (per run 66.33) | 77.59 | 17.58 / 23.70 | 0.10.4 (be5b419ed0) |
| ap-southeast-2 | t4g.medium, ap-southeast-2a | 195.67 / 196.05 (per run 196.05) | 199.99 | 5.30 / 7.71 | 0.10.4 (be5b419ed0) |
| sa-east-1 | t4g.medium, sa-east-1a | 110.50 / 110.87 (per run 110.78) | 117.73 | 15.98 / 20.60 | 0.10.4 (be5b419ed0) |
| ap-northeast-1 | t4g.medium, ap-northeast-1b | 148.14 / 147.60 (per run 146.86) | 157.18 | 12.13 / 15.58 | 0.10.4 (be5b419ed0) |

## Native link, SSH (73.4 MB), 16 MiB batches

End-to-end MiB/s = input bytes / time until the ledger shows the last byte committed (median, bootstrap 95% CI, B = 10000). Change vs size-only: difference of medians in % with its CI.

| Region | Mode | Runs | Drain s | MiB/s [95% CI] | vs size-only % [CI] | vs us-east-1 % [CI] | CPU s | Wire tx Mbit/s | SDK retries |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| eu-west-1 | size-only | 10 | 5.94 | 11.78 [11.29, 12.30] | – | -43.3 [-45.8, -40.7] | 0.76 | 7.30 | 0 |
| eu-west-1 | sha256-store | 10 | 6.12 | 11.44 [11.23, 11.67] | -2.9 [-7.1, 1.7] | -44.2 [-45.2, -43.0] | 0.76 | 7.16 | 0 |
| eu-west-1 | blake3-readback | 10 | 7.72 | 9.07 [8.80, 9.22] | -23.0 [-26.6, -19.3] | -51.8 [-53.4, -50.9] | 0.77 | 5.75 | 0 |
| ap-southeast-2 | size-only | 10 | 10.36 | 6.76 [6.31, 6.85] | – | -67.5 [-69.6, -66.9] | 0.79 | 4.22 | 0 |
| ap-southeast-2 | sha256-store | 10 | 11.30 | 6.20 [5.97, 6.25] | -8.3 [-11.8, -2.4] | -69.8 [-71.0, -69.3] | 0.79 | 3.87 | 0 |
| ap-southeast-2 | blake3-readback | 10 | 16.30 | 4.30 [4.18, 4.37] | -36.4 [-38.3, -32.1] | -77.2 [-77.9, -76.8] | 0.84 | 2.72 | 0 |
| sa-east-1 | size-only | 10 | 7.28 | 9.62 [9.59, 9.67] | – | -53.7 [-54.2, -53.2] | 0.75 | 5.97 | 0 |
| sa-east-1 | sha256-store | 10 | 8.08 | 8.66 [8.35, 8.68] | -10.0 [-13.3, -9.7] | -57.8 [-59.5, -57.3] | 0.77 | 5.40 | 0 |
| sa-east-1 | blake3-readback | 10 | 11.01 | 6.36 [6.23, 6.62] | -33.9 [-35.5, -31.2] | -66.2 [-67.1, -64.8] | 0.83 | 4.03 | 0 |
| ap-northeast-1 | size-only | 10 | 8.76 | 7.99 [7.78, 8.07] | – | -61.6 [-62.7, -61.0] | 0.76 | 4.96 | 0 |
| ap-northeast-1 | sha256-store | 10 | 9.54 | 7.34 [7.19, 7.48] | -8.1 [-10.2, -4.8] | -64.2 [-65.0, -63.3] | 0.75 | 4.61 | 0 |
| ap-northeast-1 | blake3-readback | 10 | 12.85 | 5.45 [5.32, 5.53] | -31.8 [-33.8, -29.7] | -71.1 [-71.8, -70.5] | 0.82 | 3.44 | 0 |

## Low bandwidth: kernel shaping (tc, both directions) vs VTOP's egress cap (uploads only)

Upload body rate = object bytes / drain time; of cap = that rate in Mbit/s over the cap. Calibration = timed 2 MiB PUT/GET through the same tc shaping.

| Region | Condition | Mode | Runs | Drain s | MiB/s | Upload body Mbit/s (of cap) | Wire tx / rx Mbit/s | Calibration PUT / GET Mbit/s | SDK retries |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| eu-west-1 | tc10 | sha256-store | 3 | 8.84 | 7.92 | 4.66 (0.47) | 4.94 / 0.13 | 8.25 / 8.80 | 0 |
| eu-west-1 | tc10 | blake3-readback | 3 | 14.08 | 4.97 | 2.92 (0.29) | 3.20 / 3.21 | 8.25 / 8.80 | 0 |
| eu-west-1 | cap10 | sha256-store | 3 | 8.51 | 8.22 | 4.83 (0.48) | 5.12 / 0.10 | – / – | 0 |
| eu-west-1 | cap10 | blake3-readback | 3 | 9.71 | 7.21 | 4.24 (0.42) | 4.55 / 4.52 | – / – | 0 |
| eu-west-1 | tc2 | sha256-store | 3 | 25.10 | 2.79 | 1.64 (0.82) | 1.75 / 0.05 | 1.90 / 1.91 | 0 |
| eu-west-1 | tc2 | blake3-readback | 3 | 47.38 | 1.48 | 0.87 (0.43) | 0.95 / 0.94 | 1.90 / 1.91 | 0 |
| eu-west-1 | cap2 | sha256-store | 3 | 25.06 | 2.79 | 1.64 (0.82) | 1.76 / 0.05 | – / – | 0 |
| eu-west-1 | cap2 | blake3-readback | 3 | 26.45 | 2.65 | 1.55 (0.78) | 1.69 / 1.54 | – / – | 0 |
| ap-southeast-2 | tc10 | sha256-store | 3 | 13.40 | 5.23 | 3.07 (0.31) | 3.25 / 0.09 | 5.72 / 5.66 | 0 |
| ap-southeast-2 | tc10 | blake3-readback | 3 | 24.15 | 2.90 | 1.70 (0.17) | 1.88 / 2.06 | 5.72 / 5.66 | 0 |
| ap-southeast-2 | cap10 | sha256-store | 3 | 12.80 | 5.47 | 3.21 (0.32) | 3.42 / 0.08 | – / – | 0 |
| ap-southeast-2 | cap10 | blake3-readback | 3 | 16.75 | 4.18 | 2.46 (0.25) | 2.63 / 2.65 | – / – | 0 |
| ap-southeast-2 | tc2 | sha256-store | 3 | 31.25 | 2.24 | 1.32 (0.66) | 1.41 / 0.04 | 1.79 / 1.85 | 3 |
| ap-southeast-2 | tc2 | blake3-readback | 3 | 56.37 | 1.24 | 0.73 (0.36) | 0.80 / 0.83 | 1.79 / 1.85 | 5 |
| ap-southeast-2 | cap2 | sha256-store | 3 | 29.45 | 2.38 | 1.40 (0.70) | 1.50 / 0.05 | – / – | 0 |
| ap-southeast-2 | cap2 | blake3-readback | 3 | 33.28 | 2.10 | 1.24 (0.62) | 1.33 / 1.34 | – / – | 0 |
| sa-east-1 | tc10 | sha256-store | 3 | 10.37 | 6.75 | 3.97 (0.40) | 4.20 / 0.11 | 7.15 / 6.97 | 0 |
| sa-east-1 | tc10 | blake3-readback | 3 | 17.07 | 4.10 | 2.41 (0.24) | 2.67 / 2.69 | 7.15 / 6.97 | 0 |
| sa-east-1 | cap10 | sha256-store | 3 | 9.74 | 7.19 | 4.22 (0.42) | 4.50 / 0.10 | – / – | 0 |
| sa-east-1 | cap10 | blake3-readback | 3 | 12.05 | 5.81 | 3.42 (0.34) | 3.68 / 3.33 | – / – | 0 |
| sa-east-1 | tc2 | sha256-store | 3 | 26.74 | 2.62 | 1.54 (0.77) | 1.63 / 0.05 | 1.85 / 1.89 | 0 |
| sa-east-1 | tc2 | blake3-readback | 3 | 49.39 | 1.42 | 0.83 (0.42) | 0.91 / 0.92 | 1.85 / 1.89 | 0 |
| sa-east-1 | cap2 | sha256-store | 3 | 26.50 | 2.64 | 1.55 (0.78) | 1.67 / 0.06 | – / – | 0 |
| sa-east-1 | cap2 | blake3-readback | 3 | 28.55 | 2.45 | 1.44 (0.72) | 1.56 / 1.55 | – / – | 0 |
| ap-northeast-1 | tc10 | sha256-store | 3 | 11.54 | 6.07 | 3.56 (0.36) | 3.77 / 0.11 | 6.11 / 6.48 | 0 |
| ap-northeast-1 | tc10 | blake3-readback | 3 | 20.36 | 3.44 | 2.02 (0.20) | 2.23 / 2.35 | 6.11 / 6.48 | 0 |
| ap-northeast-1 | cap10 | sha256-store | 3 | 10.85 | 6.46 | 3.79 (0.38) | 4.02 / 0.09 | – / – | 0 |
| ap-northeast-1 | cap10 | blake3-readback | 3 | 13.67 | 5.12 | 3.01 (0.30) | 3.25 / 3.22 | – / – | 0 |
| ap-northeast-1 | tc2 | sha256-store | 3 | 28.29 | 2.48 | 1.45 (0.73) | 1.55 / 0.04 | 1.83 / 1.87 | 0 |
| ap-northeast-1 | tc2 | blake3-readback | 3 | 51.48 | 1.36 | 0.80 (0.40) | 0.87 / 0.88 | 1.83 / 1.87 | 0 |
| ap-northeast-1 | cap2 | sha256-store | 3 | 27.83 | 2.52 | 1.48 (0.74) | 1.59 / 0.04 | – / – | 0 |
| ap-northeast-1 | cap2 | blake3-readback | 3 | 30.47 | 2.30 | 1.35 (0.68) | 1.47 / 1.45 | – / – | 0 |

## Loss and jitter (netem on egress), store SHA-256

| Region | Condition | Runs | Drain s | × native drain | MiB/s | SDK retries | Failed batches |
|---|---|---:|---:|---:|---:|---:|---:|
| eu-west-1 | loss1 | 3 | 13.40 | 2.19 | 5.22 | 0 | 0 |
| eu-west-1 | loss5 | 3 | 48.62 | 7.95 | 1.44 | 0 | 0 |
| eu-west-1 | jitter | 3 | 7.83 | 1.28 | 8.94 | 0 | 0 |
| ap-southeast-2 | loss1 | 3 | 41.21 | 3.65 | 1.70 | 2 | 0 |
| ap-southeast-2 | loss5 | 3 | 136.47 | 12.08 | 0.51 | 1 | 0 |
| ap-southeast-2 | jitter | 3 | 12.24 | 1.08 | 5.72 | 0 | 0 |
| sa-east-1 | loss1 | 3 | 25.00 | 3.09 | 2.80 | 0 | 0 |
| sa-east-1 | loss5 | 3 | 77.89 | 9.64 | 0.90 | 0 | 0 |
| sa-east-1 | jitter | 3 | 9.24 | 1.14 | 7.58 | 0 | 0 |
| ap-northeast-1 | loss1 | 3 | 32.47 | 3.41 | 2.16 | 0 | 0 |
| ap-northeast-1 | loss5 | 3 | 119.83 | 12.57 | 0.58 | 0 | 1 |
| ap-northeast-1 | jitter | 3 | 12.84 | 1.35 | 5.46 | 0 | 0 |

## Partition (all egress but link-local and the VPC dropped for 60 s, mid-upload)

| Region | Committed at cut / size | Commits during cut | First commit after restore s | Tx resumed s | Drain after restore s | SDK retries | Failed batches | Complete, unsafe |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| eu-west-1 | 0 / 73417507 | 0 | 2.03 | 0.88 | 6.53 | 3 | 1 | True, 0 |
| ap-southeast-2 | 0 / 73417507 | 0 | 4.70 | 2.24 | 12.61 | 3 | 1 | True, 0 |
| sa-east-1 | 0 / 73417507 | 0 | 2.95 | 1.36 | 8.82 | 3 | 1 | True, 0 |
| ap-northeast-1 | 0 / 73417507 | 0 | 2.70 | 1.05 | 9.48 | 3 | 1 | True, 0 |

## SIGKILL during upload, then restart

| Region | Mode | Committed at kill / size | Restart to drain s | Duplicate bytes | Unreferenced objects | Committed rows sharing an object | Replays | Complete, unsafe |
|---|---|---:|---:|---:|---:|---:|---:|---|
| eu-west-1 | sha256-store | 0 / 73417507 | 6.44 | 0 | 0 | 0 | 1 | True, 0 |
| eu-west-1 | blake3-readback | 0 / 73417507 | 7.59 | 0 | 0 | 0 | 1 | True, 0 |
| ap-southeast-2 | sha256-store | 0 / 73417507 | 11.19 | 0 | 0 | 0 | 1 | True, 0 |
| ap-southeast-2 | blake3-readback | 0 / 73417507 | 16.24 | 0 | 0 | 0 | 1 | True, 0 |
| sa-east-1 | sha256-store | 0 / 73417507 | 8.10 | 0 | 0 | 0 | 1 | True, 0 |
| sa-east-1 | blake3-readback | 0 / 73417507 | 11.63 | 0 | 0 | 0 | 1 | True, 0 |
| ap-northeast-1 | sha256-store | 0 / 73417507 | 9.30 | 0 | 0 | 0 | 1 | True, 0 |
| ap-northeast-1 | blake3-readback | 0 / 73417507 | 12.08 | 0 | 0 | 0 | 1 | True, 0 |

## Policed uplink (policer at the rate shown, 5,000 B bucket; 32 MiB SSH slice, uncompressed, multipart)

Treatment = shipped deadline (300 s + body / 4,096 B/s per attempt, #663); control = fixed 120 s (request_min_bytes_per_second 10^9), 480 s window.

| Region | Arm | Committed / size | Drain s | Longest seal-to-commit s | Wire tx Mbit/s | SDK retries | Failed batches | Unsafe |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| eu-west-1 | policed (1 Mbit/s) | 33554338 / 33554338 | 361.20 | 189.40 | 0.78 | 0 | 0 | 0 |
| eu-west-1 | note | no batch took > 300 s from seal to commit: here the treatment is NOT a #663 regression check (the old fixed deadline would have passed too) | | | | | | |
| eu-west-1 | policed-fixed (1 Mbit/s) | 0 / 33554338 | – | – | 0.89 | 2 | 0 | 0 |
| ap-southeast-2 | policed (1 Mbit/s) | 33554338 / 33554338 | 644.85 | 329.40 | 0.44 | 0 | 0 | 0 |
| ap-southeast-2 | policed-fixed (1 Mbit/s) | 0 / 33554338 | – | – | 0.67 | 2 | 0 | 0 |
| sa-east-1 | policed (1 Mbit/s) | 33554338 / 33554338 | 446.61 | 223.81 | 0.63 | 0 | 0 | 0 |
| sa-east-1 | note | no batch took > 300 s from seal to commit: here the treatment is NOT a #663 regression check (the old fixed deadline would have passed too) | | | | | | |
| sa-east-1 | policed-fixed (1 Mbit/s) | 0 / 33554338 | – | – | 0.80 | 2 | 0 | 0 |
| ap-northeast-1 | policed (1 Mbit/s) | 33554338 / 33554338 | 535.89 | 294.92 | 0.53 | 0 | 0 | 0 |
| ap-northeast-1 | note | no batch took > 300 s from seal to commit: here the treatment is NOT a #663 regression check (the old fixed deadline would have passed too) | | | | | | |
| ap-northeast-1 | policed-fixed (1 Mbit/s) | 0 / 33554338 | – | – | 0.70 | 2 | 0 | 0 |

## Interpretation constraints

- One VM per region, one time window; the path to S3 is the public AWS network between regions at that time.
- Bandwidth limits and loss are emulated on the VM; the distance (RTT) is real.
- The engine cap limits upload bodies only; tc shapes both directions (read-back downloads too).
- Faults ran once per region (4 trials each across regions): they show behaviour, not rates.
- Unresolved differences (CI includes 0) are not claimed as effects.
