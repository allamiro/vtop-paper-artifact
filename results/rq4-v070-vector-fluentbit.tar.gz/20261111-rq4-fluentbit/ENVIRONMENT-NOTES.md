# Environment notes for E-RQ4-B, Fluent Bit (20261111-rq4-fluentbit, C23)

Configuration, commit semantics and sources: `../../configs/README.md`, section "C23".

## Shared host

The campaign ran 20:10:35-20:41:35 (+0100) on 2026-11-11, one invocation, seed 20261111, after the
other agent's timing-sensitive cost campaign (`rq3-cost-ablation/code/exp_minio_cost.py`) had
finished (its last invocation ended 19:50:05). The driver checked for that process before every
trial (`--pause-while`, 5 consecutive absent 60 s polls to resume); it never paused, and
`run.json` has no `pauses`. The Vector campaign ran before it on the same host (see that folder's
notes for the pause history). A first start at 19:24 failed before any trial (relative bind-mount
path for `docker run -v`, fixed); its empty folder was deleted.

Elapsed times (`elapsed_s`) are not a performance result (Python fault proxy, settle waits, consumer
group rebalances after each restart); the outcomes reported are oracle safety outcomes.

## Notes on the outcomes

- Fluent Bit commits the Kafka offset when records enter its input buffer (configs/README.md), so
  the committed offset reaches the end of the topic while uploads are still pending. `at_target`
  records the oracle at the first moment the commit was seen at the target: in every `corrupt` and
  `lost` trial the commit was already at the end while records were still waiting in Fluent Bit's
  buffer (`at_target.lost_committed_records` 64,481-66,423: the damaged object's records plus those
  not yet uploaded, against 41,308-43,250, the damaged object only, in the final state). Both numbers come from `trials.jsonl`.
- `kill` trials: at every first kill, and in t01 also at the second, the committed offset of all
  four partitions was ahead of the intact archive (`events[].unsafe`), i.e. committed records were
  only in Fluent Bit's local filesystem buffer. After each `docker start` the container's file
  system (filesystem storage chunks under `storage.path`, the s3 `store_dir`) was still there; the
  log shows the `storage_backlog` input re-queueing the chunks and the s3 output uploading them, and
  every trial ended complete, with no committed record missing and no duplicate. A failure that
  loses the local disk (not injected here) would lose the records the commit had already passed.
- No sink log contains a warning or an error in any trial, including the trials whose acknowledged
  object was corrupted or deleted.
- `vtop_commit` in `run.json` is the harness pin written by the shared driver; VTOP did not run here.
- Evidence bundles (config, proxy log, gzip'd sink log): `evidence-corrupt-t00/`,
  `evidence-lost-t00/`, `evidence-kill-t01/`.
