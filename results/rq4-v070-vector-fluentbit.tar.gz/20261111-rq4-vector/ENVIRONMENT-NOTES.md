# Environment notes for E-RQ4-B, Vector (20261111-rq4-vector, C23)

Configuration, commit semantics and sources: `../../configs/README.md`, section "C23".

## Shared host and pauses

The host was shared with another agent's timing-sensitive campaign
(`research/experiments/rq3-cost-ablation/code/exp_minio_cost.py`, results
`rq3-cost-ablation/results/20261111-v070-minio-cost/`), which runs as back-to-back invocations
with gaps of seconds between them. On the coordinator's request this campaign was paused while
that one ran. Times are local (+0100), 2026-11-11.

| Event | Time |
|---|---|
| First start; aborted before any trial (driver bug: relative bind-mount path for `docker run -v`; fixed by resolving the trial folder to an absolute path). The empty result folders were deleted. | 19:23:5x-19:24:46 |
| Pause request received; containers this campaign started (Kafka, MinIO, proxy) removed | 19:24:46 |
| Resume (no `exp_minio_cost.py` process at 5 consecutive 60 s polls) | 19:30:47 |
| Infra up + trial `corrupt` t00 (19:31:13-19:31:36) | 19:30:47-19:31:36 |
| Pause (cost campaign running); Kafka/MinIO stopped | 19:31:36 / 19:34:19 |
| Resume (top-up 1, seed 20261112): Kafka/MinIO restarted, trial `corrupt` t01 | 19:39:00-19:39:35 |
| Pause (recorded in `run.json` `pauses`); Kafka/MinIO stopped by the driver | 19:39:27 |
| Resume (driver's own gate: one absent poll), trial `corrupt` t02 | 19:47:10-19:47:58 |
| Pause; Kafka/MinIO stopped; driver stopped and the gate changed to require 5 consecutive absent 60 s polls | ~19:48:00 |
| Resume after 5 absent polls (the cost campaign's last invocation finished 19:50:05); `corrupt` t03-t09 (seed 20261114), then `lost` t00-t09 and `kill` t00-t04 (seed 20261115), no further pause | 19:54:44-20:10:32 |

**Overlap with the cost campaign.** The resume rule used at first (resume as soon as no
`exp_minio_cost.py` process is running) did not account for that campaign's short gaps between
invocations. This campaign's activity therefore overlapped cost-campaign invocations in three
windows: about 19:30:47-19:31:36 (Kafka/MinIO start, topic load, trial t00; the cost `ssh` chunk
finished 19:31:38), 19:39:00-19:39:35 (trial t01; cost `bgl` reps 5-9 chunk, finished 19:41:51)
and 19:47:10-19:47:58 (trial t02; cost `hdfs` reps 7-9 chunk, running at 19:48:02). The cost runs
in those windows may be distorted and should be checked or re-run by their owner. From 19:48
on, a pause ends only after 5 consecutive absent polls (`--quiet-polls 5`).

Elapsed times (`elapsed_s`) are therefore not a performance result; the outcomes reported are
safety outcomes from the oracle and do not depend on timing (as in `20261111-v070-rq4`).

## Trial numbering and seeds

The matrix was run in several invocations of the driver (top-ups, recorded in `run.json`): the
first invocation (seed 20261111) ran `corrupt` t00 and was stopped at a pause; the top-ups ran the
remaining trials with the seeds listed in `run.json` `top_ups`. The faulted write index N is drawn
per trial from the invocation's seed and recorded in `nth_faulted_write`.

## Other notes

- `vtop_commit` in `run.json` is the harness pin written by the shared driver; VTOP itself did not
  run in this campaign.
- No sink log (`raw/*/vector.log`) contains a warning or an error in any trial, including the trials
  whose acknowledged object was then corrupted or deleted: Vector did not notice the damage.
- In the `kill` trials no offset was committed before any of the three kills in t00, t01 and t04
  (`events[].committed` is 0 or empty): each life was 4-8 s, Vector commits stored offsets every
  5 s (`commit_interval_ms` default), and after a restart the new consumer waits for the group to
  rebalance. Each restart therefore re-read from the start or from the last commit, which is why
  these trials archived up to 1.6 M duplicate records. This is the documented at-least-once
  behaviour, reported as measured.
- Evidence bundles (config, proxy log, gzip'd sink log) for one trial per fault:
  `evidence-corrupt-t00/`, `evidence-lost-t00/`, `evidence-kill-t01/`. The full raw folders stay out
  of git.
