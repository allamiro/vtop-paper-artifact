# E-RQ5-SCALE: 20261121T153823Z-scale

Hosts: 8 (t4g.large; us-east-1a). Steps executed 46/46; engine-runs 198 (198 passing: drained, oracle byte-exact and complete, 0 unsafe, log/receipt/ledger/HEAD agree, single-PUT). Unsafe: 0.

Medians with percentile-bootstrap 95% CI (B = 10000). Per-engine = steady MiB/s of one engine; aggregate = sum over the step's engines; efficiency = aggregate(N) / (N x aggregate(1)).

| N | Steps | Aggregate MiB/s | Efficiency | Per-engine MiB/s | Per-engine vs N=1 % | Window MiB/s | Records/s | S3 att/s (peak) | Retries | Throttle verdicts | ENA events | Host CPU % |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 10 | 46.61 [45.95, 47.02] | — | 46.61 [45.95, 47.02] | — | 46.359 | 346122.5 | 16.735 (21) | 0 | 0 | 407 | 25.3315 |
| 2 | 10 | 92.96 [91.59, 93.76] | 0.997 [0.980, 1.013] | 46.31 [45.88, 46.64] | -0.63 [-1.85, 0.99] | 92.497 | 690343.55 | 33.15 (42) | 0 | 0 | 916 | 25.308 |
| 4 | 10 | 188.14 [185.46, 190.12] | 1.009 [0.990, 1.029] | 47.18 [46.77, 47.47] | 1.22 [0.02, 2.90] | 186.7755 | 1397168.6 | 66.005 (79) | 0 | 0 | 2805 | 25.1178 |
| 8 | 10 | 373.09 [368.91, 377.68] | 1.001 [0.985, 1.021] | 46.68 [46.40, 46.98] | 0.15 [-1.00, 1.72] | 369.8415 | 2770655.2 | 130.41 (157) | 0 | 0 | 4557 | 25.3178 |

**Size-only control at N = 8** (5 steps): per-engine 49.44 [48.96, 49.85] MiB/s; store SHA-256 vs size-only, per engine -5.58 [-6.62, -4.52] %, aggregate -5.38 [-6.69, -4.10] %. S3 attempts per engine-run: {'size-only': 478.0, 'sha256-store': 573.0}.

## Proposed H3.7 prediction (CI facts only)

- N = 2: efficiency CI lower bound ≥ 0.90: True; per-engine change CI includes 0: True; throttle verdicts 0, retries 0
- N = 4: efficiency CI lower bound ≥ 0.90: True; per-engine change CI includes 0: False; throttle verdicts 0, retries 0
- N = 8: efficiency CI lower bound ≥ 0.90: True; per-engine change CI includes 0: True; throttle verdicts 0, retries 0
- every engine-run passed the oracle with 0 unsafe: True

## Interpretation constraints

- One region, one AZ, one time window; t4g instances with burstable CPU (unlimited) and network allowances.
- Engines are independent (one ledger and one source set each); this is horizontal scale-out, not a shared-ledger cluster.
- S3 request counts are the engines' own SDK attempts; the oracle's and coordination requests are excluded.
- Unresolved differences (CI includes 0) are not claimed as effects.
