# Kafka partition stall, trial hdfs-p4-t02 (finding F5)

VTOP v0.7.0 tag (`6c8f386`), topic `hdfs-p4` (4 partitions, first 2 M
HDFS_v1 lines), consumer group `vtop-lab-hdfs-p4-2-1794333939`.

- `engine-logs.tar.gz`: JSON logs of all five engine processes
  (`engine-001`–`004` = the four killed lives, `engine-005` = the final
  900 s drain, stopped by SIGTERM).
- `ledger-batches.csv`: the SQLite ledger after the trial (54 rows, all
  `source_committed`).
- `config.yaml`: the engine configuration (paths relative to `research/`).

What happened: `engine-005` read partition 0 contiguously from the
ledger cursor 168,776 to offset 447,960, committed offset 447,961 at
18:05:58Z, and then received no record from partition 0 until it was
stopped at 18:20:53Z (`read_cycle_profile`: `records_read: 0`,
`empty_sources: 1`, no WARN or ERROR line). Partitions 1–3 reached their
log ends. The broker's committed offsets at the end were
{0: 447961, 1: 475075, 2: 506425, 3: 490358}; the log end of partition 0
is 528,142. The oracle found 0 unsafe commits; 80,181 records of
partition 0 were not archived but also not committed.

Restart check (not part of the harness): a fresh `vtopctl run` on a copy
of this ledger with the same consumer group archived and committed
partition 0 to 528,142 within 2 s (56 rows, all `source_committed`).
