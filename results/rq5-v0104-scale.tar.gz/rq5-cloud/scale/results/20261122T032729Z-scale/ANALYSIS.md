# E-RQ5-SCALE: 20261122T032729Z-scale

Hosts: 8 (t4g.large; us-east-1a). Steps executed 46/46; engine-runs 198 (198 passing: drained, oracle byte-exact and complete, 0 unsafe, log/receipt/ledger/HEAD agree, single-PUT). Unsafe: 0.

Medians with percentile-bootstrap 95% CI (B = 10000). Per-engine = steady MiB/s of one engine; aggregate = sum over the step's engines; efficiency = aggregate(N) / (N x aggregate(1)).

| N | Steps | Aggregate MiB/s | Efficiency | Per-engine MiB/s | Per-engine vs N=1 % | Window MiB/s | Records/s | S3 att/s (peak) | Retries | Throttle verdicts | ENA events | Host CPU % |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 10 | 45.28 [44.27, 46.67] | — | 45.28 [44.27, 46.67] | — | 45.28 | 336263.65 | 16.275 (21) | 0 | 0 | 609 | 25.188 |
| 2 | 10 | 91.92 [90.58, 93.36] | 1.015 [0.982, 1.045] | 45.93 [45.61, 46.34] | 1.44 [-1.73, 4.14] | 91.4785 | 682602.5 | 32.85 (40) | 0 | 0 | 1222 | 25.186 |
| 4 | 10 | 185.50 [182.88, 186.70] | 1.024 [0.989, 1.049] | 46.35 [45.82, 46.61] | 2.37 [-0.95, 4.81] | 184.1845 | 1377576.1 | 65.36 (80) | 0 | 0 | 3124 | 25.0832 |
| 8 | 10 | 369.29 [366.37, 372.33] | 1.019 [0.988, 1.045] | 46.31 [45.84, 46.48] | 2.27 [-1.19, 4.69] | 366.3425 | 2742413.8 | 128.82 (154) | 0 | 0 | 4142 | 25.1245 |

**Size-only control at N = 8** (5 steps): per-engine 48.51 [48.18, 48.74] MiB/s; store SHA-256 vs size-only, per engine -4.53 [-5.69, -3.73] %, aggregate -4.71 [-5.80, -3.81] %. S3 attempts per engine-run: {'size-only': 478.0, 'sha256-store': 573.0}.

## Proposed H3.7 prediction (CI facts only)

- N = 2: efficiency CI lower bound ≥ 0.90: True; per-engine change CI includes 0: True; throttle verdicts 0, retries 0
- N = 4: efficiency CI lower bound ≥ 0.90: True; per-engine change CI includes 0: True; throttle verdicts 0, retries 0
- N = 8: efficiency CI lower bound ≥ 0.90: True; per-engine change CI includes 0: True; throttle verdicts 0, retries 0
- every engine-run passed the oracle with 0 unsafe: True

## Interpretation constraints

- One region, one AZ, one time window; t4g instances with burstable CPU (unlimited) and network allowances.
- Engines are independent (one ledger and one source set each); this is horizontal scale-out, not a shared-ledger cluster.
- S3 request counts are the engines' own SDK attempts; the oracle's and coordination requests are excluded.
- Unresolved differences (CI includes 0) are not claimed as effects.
