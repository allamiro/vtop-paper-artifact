# E-RQ5-COST: verification cost on EC2 + Amazon S3

Run `20261121T012945Z-i-072d88074e58c7845`: t4g.large in us-east-1a, AMI `ami-0697409d504dfb93d`; vtop-engine 0.10.2 (0abf11696e47f4db871bd4c2cda882756c114390), archive SHA-256 `5872e5a34b75a38425fcb99db2f78631b89d121b6a615a570192d5d4f2ccdf39`. AWS_REQUEST_CHECKSUM_CALCULATION=`None`.
30 runs (30 passing: drained, oracle byte-exact, log/receipt/ledger/HEAD agree, single-PUT); order shuffled with seed 20261121.

Throughput is the median steady-state MiB/s (bytes at the second-to-last commit over its time) with a
percentile-bootstrap 95% CI (B = 10000). The difference is the variant median minus the size-only median,
with a bootstrap CI on the difference of medians; negative values are slowdowns. Batch sizes are measured
from the ledger (uncompressed bytes per committed batch).

| Dataset | Mode | MiB/s [95% CI] | Diff vs size-only, MiB/s [95% CI] | Change % [95% CI] | CPU s/GiB | Batches | Median batch MiB | Read-back MiB |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| HDFS | size-only | 49.21 [48.62, 49.64] | 0.00 [0.00, 0.00] | 0.00% [0.00, 0.00] | 10.123 | 95 | 16.00 | 0.0 |
| HDFS | sha256-store | 46.71 [45.84, 47.80] | -2.49 [-3.50, -1.28] | -5.07% [-7.06, -2.62] | 10.190 | 95 | 16.00 | 0.0 |
| HDFS | blake3-readback | 38.82 [38.50, 39.57] | -10.39 [-10.97, -9.42] | -21.11% [-22.19, -19.23] | 11.058 | 95 | 16.00 | 145.9 |

## H3.5 prediction, per dataset (CI facts only)

- HDFS: store SHA-256 CI includes 0: False; BLAKE3 read-back CI below 0: True

## Environment checks

- hdfs/size-only: max CPU steal 0.238%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 700, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.2579, 'total_ms': 233.2737}
- hdfs/sha256-store: max CPU steal 0.314%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 726, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.3, 'total_ms': 251.7158}
- hdfs/blake3-readback: max CPU steal 0.141%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 999, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.2368, 'total_ms': 316.1263}

## Interpretation constraints

- One instance, one AZ, one time window; not a distributed deployment.
- Stage timings are reported only if the engine logged them (v0.10.2 #843); absent is not zero.
- Unresolved differences (CI includes 0) are not claimed as effects.
