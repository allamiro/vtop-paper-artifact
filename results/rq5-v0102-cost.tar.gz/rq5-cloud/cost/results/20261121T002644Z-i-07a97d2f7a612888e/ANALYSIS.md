# E-RQ5-COST: verification cost on EC2 + Amazon S3

Run `20261121T002644Z-i-07a97d2f7a612888e`: t4g.medium in us-east-1a, AMI `ami-0697409d504dfb93d`; vtop-engine 0.10.2 (0abf11696e47f4db871bd4c2cda882756c114390), archive SHA-256 `5872e5a34b75a38425fcb99db2f78631b89d121b6a615a570192d5d4f2ccdf39`. AWS_REQUEST_CHECKSUM_CALCULATION=`None`.
90 runs (90 passing: drained, oracle byte-exact, log/receipt/ledger/HEAD agree, single-PUT); order shuffled with seed 20261121.

Throughput is the median steady-state MiB/s (bytes at the second-to-last commit over its time) with a
percentile-bootstrap 95% CI (B = 10000). The difference is the variant median minus the size-only median,
with a bootstrap CI on the difference of medians; negative values are slowdowns. Batch sizes are measured
from the ledger (uncompressed bytes per committed batch).

| Dataset | Mode | MiB/s [95% CI] | Diff vs size-only, MiB/s [95% CI] | Change % [95% CI] | CPU s/GiB | Batches | Median batch MiB | Read-back MiB |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| SSH | size-only | 41.49 [37.95, 44.88] | 0.00 [0.00, 0.00] | 0.00% [0.00, 0.00] | 10.931 | 5 | 16.00 | 0.0 |
| SSH | sha256-store | 43.53 [41.34, 44.83] | 2.04 [-1.65, 5.57] | 4.93% [-3.67, 13.73] | 10.830 | 5 | 16.00 | 0.0 |
| SSH | blake3-readback | 35.58 [34.75, 37.22] | -5.91 [-9.06, -2.24] | -14.25% [-20.05, -5.49] | 11.688 | 5 | 16.00 | 4.9 |
| BGL | size-only | 46.70 [42.99, 48.54] | 0.00 [0.00, 0.00] | 0.00% [0.00, 0.00] | 10.280 | 45 | 16.00 | 0.0 |
| BGL | sha256-store | 44.59 [40.95, 47.01] | -2.11 [-6.16, 2.87] | -4.52% [-13.09, 6.47] | 10.196 | 45 | 16.00 | 0.0 |
| BGL | blake3-readback | 37.99 [32.47, 38.68] | -8.72 [-14.24, -4.92] | -18.67% [-31.00, -11.45] | 10.900 | 45 | 16.00 | 67.1 |
| HDFS | size-only | 46.91 [45.25, 48.10] | 0.00 [0.00, 0.00] | 0.00% [0.00, 0.00] | 10.527 | 95 | 16.00 | 0.0 |
| HDFS | sha256-store | 41.34 [36.17, 44.53] | -5.58 [-10.84, -2.56] | -11.89% [-23.18, -5.26] | 10.655 | 95 | 16.00 | 0.0 |
| HDFS | blake3-readback | 37.64 [31.69, 38.56] | -9.27 [-15.40, -7.59] | -19.75% [-32.55, -16.44] | 11.207 | 95 | 16.00 | 145.9 |

## H3.5 prediction, per dataset (CI facts only)

- SSH: store SHA-256 CI includes 0: True; BLAKE3 read-back CI below 0: True
- BGL: store SHA-256 CI includes 0: True; BLAKE3 read-back CI below 0: True
- HDFS: store SHA-256 CI includes 0: False; BLAKE3 read-back CI below 0: True

## Environment checks

- ssh/size-only: max CPU steal 0.277%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 0, max batch 16777184 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.2, 'total_ms': 250.4}
- ssh/sha256-store: max CPU steal 0.287%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 0, max batch 16777184 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.2, 'total_ms': 245.9}
- ssh/blake3-readback: max CPU steal 1.134%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 0, max batch 16777184 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.2, 'total_ms': 313.2}
- bgl/size-only: max CPU steal 0.752%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 176, max batch 16777209 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.3111, 'total_ms': 249.3}
- bgl/sha256-store: max CPU steal 0.604%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 366, max batch 16777209 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.2222, 'total_ms': 266.0222}
- bgl/blake3-readback: max CPU steal 0.609%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 273, max batch 16777209 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.2889, 'total_ms': 331.9333}
- hdfs/size-only: max CPU steal 1.035%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 610, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.3474, 'total_ms': 245.4421}
- hdfs/sha256-store: max CPU steal 0.732%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 795, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.4526, 'total_ms': 291.9211}
- hdfs/blake3-readback: max CPU steal 2.252%, max engine disk read 0.0 MiB, ENA allowance-exceeded events 1035, max batch 16777216 B (0 runs over max_bytes), per-batch stage ms {'state_write_ms': 7.4842, 'total_ms': 325.2474}

## Interpretation constraints

- One instance, one AZ, one time window; not a distributed deployment.
- Stage timings are reported only if the engine logged them (v0.10.2 #843); absent is not zero.
- Unresolved differences (CI includes 0) are not claimed as effects.
